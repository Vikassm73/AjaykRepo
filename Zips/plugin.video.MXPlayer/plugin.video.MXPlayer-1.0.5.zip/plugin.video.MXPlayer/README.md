# MXPlayer
This is a Indian Kodi App for https://www.mxplayer.in. Please note that you will not able to play DRM protected video link. 
