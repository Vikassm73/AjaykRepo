﻿# -*- coding: utf-8 -*-shToken
from __future__ import unicode_literals

import urlquick
from kodi_six import xbmcgui, xbmc
from resources.lib.contants import BASE_HEADERS, url_constructor
from resources.lib.utils import deep_get, updateQueryParams, qualityFilter, getAuth, guestToken
from codequick import Script
from codequick.script import Settings
from codequick.storage import PersistentDict
from urllib.parse import quote_plus
from urllib.request import urlopen, Request
import json
from uuid import uuid4
from base64 import b64decode
import web_pdb

class HotstarAPI:
    device_id = str(uuid4())
    country = Settings.get_string("country")
    if country == 'IN':
        country_code = '91'
    elif country == 'MY':
        country_code = '60'
    elif country == 'TH':
        country_code = '66'
    elif country == 'ID':
        country_code = '62'

    def __init__(self):
        self.session = urlquick.Session()
        self.session.headers.update(BASE_HEADERS)

    def getMenu(self):
        url = url_constructor("/o/v2/menu")
        resp = self.get(
            url, headers={"x-country-code": self.country, "x-platform-code": "firetv"})
        return deep_get(resp, "body.results.menuItems")       #  deep_get(resp["body"]["results"]["menuItems"][0]["subItem"][1], "subItem")     #    #

    def getPage(self, url):
        results = deep_get(self.get(url), "body.results")
        itmes = deep_get(results, "trays.items", []) or results.get(
            "items", [])
        nextPageUrl = results.get("nextOffsetURL") or deep_get(
            results, "trays.nextOffsetURL")
        return itmes, nextPageUrl

    def getTray(self, url, search_query=None):
        if search_query:
            url = url_constructor("/s/v1/scout?q=%s&size=30" %
                                  quote_plus(search_query))
        if "persona" in url:
            with PersistentDict("userdata.pickle") as db:
                pid = db.get("udata", {}).get("pId")
            results = self.get(url.format(pid=pid), headers={
                               "hotstarauth": getAuth(includeST=True, persona=True)})
            # ids = ",".join(map(lambda x: x.get("item_id"),
            #                deep_get(results, "data.items")))
            # url = url_constructor("/o/v1/multi/get/content?ids=" + ids)
        else:
            results = self.get(url)

        if "data" in results:
            results = results.get("data")
            if "progress_meta" in results and type(results.get("items")) is dict:
                for cID, data in results.get("progress_meta").items():
                    results["items"][cID].update(data)
        else:
            results = deep_get(results, "body.results")

        if results:
            items = results.get("items") or deep_get(results, "assets.items") or (results.get(
                "map") and list(results.get("map").values())) or deep_get(results, "trays.items") or []
            if type(items) is dict:
                items = list(items.values())
            nextPageUrl = deep_get(
                results, "assets.nextOffsetURL") or results.get("nextOffsetURL")

            totalResults = deep_get(
                results, "assets.totalResults") or results.get("totalResults")
            allResultsPageUrl = None
            if len(items) > 0 and nextPageUrl is not None and ("/season/" in nextPageUrl or items[0].get("assetType") == "EPISODE") and totalResults is not None:
                allResultsPageUrl = updateQueryParams(nextPageUrl, {"size": str(
                    totalResults), "tas": str(totalResults), "offset": "0"})

            if deep_get(results, "channelClip.clipType", "") == "LIVE":
                items.insert(0, deep_get(results, "channelClip", {}))

            return items, nextPageUrl, allResultsPageUrl
        return [], None, None

    def getPlay(self, contentId, subtag, drm=False, lang=None, partner=None, ask=False):
        # 'partner/' if partner is not None else '',
        if self.country == 'IN':
            url = url_constructor("/play/v4/playback/content/%s" % (contentId))
        else:
            url = url_constructor("/play/v3/playback/content/%s" % (contentId))
        encryption = "widevine"     # if drm else "plain"
        with PersistentDict("userdata.pickle") as db:
            xbmc.log(db["token"])
        data = '{"os_name":"Android","os_version":"7.0","app_name":"android","app_version":"7.41.0","platform":"firetv","platform_version":"7.6.0.0","client_capabilities":{"ads":["non_ssai"],"audio_channel":["stereo"],"dvr":["short"],"package":["dash","hls"],"dynamic_range":["sdr"],"video_codec":["h264"],"encryption":["widevine"],"ladder":["phone"],"container":["fmp4","ts"],"resolution":["fhd","hd"]},"drm_parameters":{"widevine_security_level":["SW_SECURE_DECODE","SW_SECURE_CRYPTO"],"hdcp_version":["HDCP_NO_DIGITAL_OUTPUT"]},"resolution":"auto"}'
        resp = self.post(url, headers=self._getPlayHeaders(includeST=True), params=self._getPlayParams(
            subtag, encryption), max_age=-1, data=data)
        
        # xbmc.log(str(resp))
        playBackSets = deep_get(resp, "data.playback_sets")
        if playBackSets is None:
            return None, None, None
        playbackUrl, licenceUrl, playbackProto = HotstarAPI._findPlayback(
            playBackSets, lang, ask)
        return playbackUrl, licenceUrl, playbackProto

    def getExtItem(self, contentId):
        url = url_constructor(
            "/o/v1/multi/get/content?ids={0}".format(contentId))
        resp = self.get(url)
        url = deep_get(resp, "body.results.map.{0}.uri".format(contentId))
        if url is None:
            return None, None, None
        resp = self.get(url)
        item = deep_get(resp, "body.results.item")
        if item.get("clipType") == "LIVE":
            item["encrypted"] = True
        return "com.widevine.alpha" if item.get("encrypted") else False, item.get("isSubTagged") and "subs-tag:%s|" % item.get("features")[0].get("subType"), item.get("title")

    def doLogin(self):

        with PersistentDict("userdata.pickle") as db:
            token = db.get("token")
            if token:
                self._refreshToken()
            else:
                token = guestToken()
                db.clear()
                db["token"] = token
                db.flush()
            hid = json.loads(json.loads(b64decode(token.split(".")[1] + "========")).get("sub")).get("hId")

        mobile = xbmcgui.Dialog().numeric(0, "Enter 10 Digit mobile number")
        url = url_constructor("/um/v3/users/%s/register?register-by=phone_otp" % (hid))
        data = {
            "phone_number": mobile,
            "country_prefix": self.country_code,
            "device_meta": {"device_name": "Chrome Browser on Windows"}
        }
        data = json.dumps(data)
        resp = self.put(url, headers=self._getPlayHeaders(
            includeST=True, includeUM=True, extra={"x-hs-device-id": self.device_id, "x-request-id": self.device_id}), data=data)
        # web_pdb.set_trace()
        if deep_get(resp, "message") == 'User verification initiated':
            OTP = xbmcgui.Dialog().numeric(0, "Enter 4 Digit OTP")
            url = url_constructor(
                "/um/v3/users/login?login-by=phone_otp")

            data = {
                "phone_number": mobile,
                "verification_code": OTP,
                "device_meta": {"device_name": "Chrome Browser on Windows"}
            }
            data = json.dumps(data)
            resp = self.put(url, headers=self._getPlayHeaders(
                includeST=True, includeUM=True, extra={"x-hs-device-id": self.device_id}), data=data)
            token = deep_get(resp, "user_identity")
            xbmc.log(token, xbmc.LOGINFO)
            if token:
                with PersistentDict("userdata.pickle") as db:
                    db["token"] = token
                    db["deviceId"] = self.device_id
                    db["udata"] = json.loads(json.loads(
                        b64decode(token.split(".")[1] + "========")).get("sub"))
                    db.flush()
                    Script.notify("Login Success", "You are logged in")

    def doLoginold(self):

        with PersistentDict("userdata.pickle") as db:
            token = db.get("token")
            if token:
                self._refreshToken()
            else:
                token = guestToken()
                db.clear()
                db["token"] = token
                db.flush()
            hid = json.loads(json.loads(b64decode(token.split(".")[1] + "========")).get("sub")).get("hId")

        mobile = xbmcgui.Dialog().numeric(0, "Enter 10 Digit mobile number")
        Cke = 'geo=IN,MH,MUMBAI,18.98,72.83,149187; x_migration_exp=true; SELECTED__LANGUAGE=eng; deviceId=71b522-5a7918-26f0ef-95a375; _gcl_au=1.1.715445255.1693821441; userHID=8bff83ab226645faa4d07c1d7f1c6aa9; userPID=32f5a09ad67f4fb8be2056baa0a7d618; userUP=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBJZCI6IiIsImF1ZCI6InVtX2FjY2VzcyIsImV4cCI6MTY5NTk3NTcyMiwiaWF0IjoxNjk1MzcwOTIyLCJpc3MiOiJUUyIsImp0aSI6IjBlYjU2NDRiYjkyNzQ5ZDg4NDgyMDY2ODZiMjc0ZjJiIiwic3ViIjoie1wiaElkXCI6XCI4YmZmODNhYjIyNjY0NWZhYTRkMDdjMWQ3ZjFjNmFhOVwiLFwicElkXCI6XCIzMmY1YTA5YWQ2N2Y0ZmI4YmUyMDU2YmFhMGE3ZDYxOFwiLFwibmFtZVwiOlwiWW91XCIsXCJpcFwiOlwiMTAzLjE3Ny4xMy4xNDZcIixcImNvdW50cnlDb2RlXCI6XCJpblwiLFwiY3VzdG9tZXJUeXBlXCI6XCJudVwiLFwidHlwZVwiOlwiZ3Vlc3RcIixcImlzRW1haWxWZXJpZmllZFwiOmZhbHNlLFwiaXNQaG9uZVZlcmlmaWVkXCI6ZmFsc2UsXCJkZXZpY2VJZFwiOlwiNzFiNTIyLTVhNzkxOC0yNmYwZWYtOTVhMzc1XCIsXCJwcm9maWxlXCI6XCJBRFVMVFwiLFwidmVyc2lvblwiOlwidjJcIixcInN1YnNjcmlwdGlvbnNcIjp7XCJpblwiOnt9fSxcImlzc3VlZEF0XCI6MTY5NTM3MDkyMjAzNixcIm1hdHVyaXR5TGV2ZWxcIjpcIkFcIixcImRwaWRcIjpcIjMyZjVhMDlhZDY3ZjRmYjhiZTIwNTZiYWEwYTdkNjE4XCIsXCJzdFwiOjEsXCJkYXRhXCI6XCJDZ3dJQUNJSWtBSEV1SUQ5cFRFS0JBZ0FFZ0FLQkFnQU1nQUtCQWdBT2dBS0JBZ0FRZ0FLckFFSUFDcW5BUW9DQ2dBS0Nnb0NDQUlZc3V5UnFBWUtid29IQ0FFVkFBQUFRQklLQ2dOdFlYSWxzMndNUFJJS0NnTjBaV3dsK25FTlBoSUtDZ05vYVc0bHRsY2RQeElLQ2dObGJtY2x6SzhSUFJJS0NnTjBZVzBsQTRHeVBSSUtDZ05pWlc0bHREWjNQUklLQ2dOcllXNGxNV0hsT3hJS0NnTnRZV3dscW5hN1BCaXk3SkdvQmdvUkNnSUlBeElGQ2dOb2FXNFlzdXlScUFZS0VRb0NDQVFTQlFvRGFHbHVHTExza2FnR1wifSIsInZlcnNpb24iOiIxXzAifQ.ICVugbBUmfhCkOEbWhE4npm125poGXOjvTvK8kbx7rc; _gid=GA1.2.1536569351.1695370925; userCountryCode=in; appLaunchCounter=2; _gat_UA-53733575-1=1; _ga=GA1.1.1449458500.1693821442; _ga_QV5FD29XJC=GS1.1.1695370924.18.1.1695371814.52.0.0; _ga_2PV8LWETCX=GS1.1.1695370924.18.1.1695371814.52.0.0; _uetsid=1d0c7f00592111ee9300010838a8f776; _uetvid=719a18204b0911ee80e3931acd44ccdb; _ga_VJTFGHZ5NH=GS1.2.1695370925.14.1.1695371814.60.0.0; AK_SERVER_TIME=1695371820; _ga_EPJ8DYH89Z=GS1.1.1695370924.18.1.1695371827.39.0.0'
        hdr = self._getPlayHeaders(
            includeST=True, includeUM=True, extra={"x-hs-device-id": self.device_id, "x-request-id": self.device_id, 
                                                   "X-Hs-Client": "platform:web;app_version:23.09.08.7;browser:Chrome;schema_version:0.0.1020",
                                                   "X-Hs-Client-Targeting": "ad_id:"+self.device_id+";user_lat:false",
                                                   "Cookie": Cke})
        url = "https://www.hotstar.com/api/internal/bff/v2/pages/1/spaces/1/widgets/8?action=sendOtp"
        data = {"body":
                {"@type": "type.googleapis.com/feature.login.InitiatePhoneLoginRequest",
                 "phone_number": mobile,
                 "initiate_by": 0,
                 "recaptcha_token": ""}}
        data = json.dumps(data)
        web_pdb.set_trace()
        resp = self.post(url, headers=hdr, data=data)
        # xbmc.log(resp, xbmc.LOGINFO)

        if deep_get(resp, "message") == 'User verification initiated':
            OTP = xbmcgui.Dialog().numeric(0, "Enter 4 Digit OTP")
            url = 'https://www.hotstar.com/api/internal/bff/v2/pages/1/spaces/1/widgets/9?action=verifyOtp'

            data = {"body": {"@type": "type.googleapis.com/feature.login.VerifyPhoneLoginRequest",
                    "phone_number": mobile,
                    "verification_code": OTP,
                    "login_device_meta": {"device_name": "Chrome Browser on LG mobile "}}}
            data = json.dumps(data)
            resp = self.post(url, headers=hdr, data=data)
            token = deep_get(resp, "success.widget_wrapper.widget.data.user_identity")
            xbmc.log(token, xbmc.LOGINFO)
            if token:
                with PersistentDict("userdata.pickle") as db:
                    db["token"] = token
                    db["deviceId"] = self.device_id
                    db["udata"] = json.loads(json.loads(
                        b64decode(token.split(".")[1] + "========")).get("sub"))
                    db.flush()
                    Script.notify("Login Success", "You are logged in")

    def doLogout(self):
        with PersistentDict("userdata.pickle") as db:
            db.clear()
            db.flush()

        Script.notify("Logout Success", "You are logged out")
        return False

    def get(self, url, **kwargs):
        try:
            response = self.session.get(url, **kwargs)  #, max_age=-1
            return response.json()
        except Exception as e:
            return self._handleError(e, url, "get", **kwargs)

    def post(self, url, **kwargs):
        try:
            response = self.session.post(url, **kwargs)
            return response.json()
        except Exception as e:
            return self._handleError(e, url, "post", **kwargs)

    def put(self, url, **kwargs):
        try:
            response = self.session.put(url, **kwargs)
            return response.json()
        except Exception as e:
            return self._handleError(e, url, "put", **kwargs)

    def _handleError(self, e, url, _rtype, **kwargs):
        if e.__class__.__name__ == "ValueError":
            Script.log("Can not parse response of request url %s" %
                       url, lvl=Script.DEBUG)
            Script.notify("Internal Error", "")
        elif e.__class__.__name__ == "HTTPError":
            if e.response.status_code == 402 or e.response.status_code == 403:
                with PersistentDict("userdata.pickle") as db:
                    if db.get("isGuest"):
                        Script.notify(
                            "Subscription Error", "Please subscribe to watch this content")
                        # executebuiltin(
                        #    "RunPlugin(plugin://plugin.video.botallen.hotstar/resources/lib/main/login/)")
                    else:
                        Script.notify(
                            "Subscription Error", "You don't have valid subscription to watch this content", display_time=2000)
            elif e.response.status_code == 401:
                new_token = self._refreshToken()
                if new_token:
                    kwargs.get("headers") and kwargs['headers'].update(
                        {"X-HS-UserToken": new_token})
                    if _rtype == "get":
                        return self.get(url, **kwargs)
                    else:
                        return self.post(url, **kwargs)
                else:
                    Script.notify("Token Error", "Token not found")

            elif e.response.status_code == 474 or e.response.status_code == 475:
                Script.notify(
                    "VPN Error", "Your VPN provider does not support Hotstar")
            elif e.response.status_code == 404 and e.response.headers.get("Content-Type") == "application/json":
                if e.response.json().get("errorCode") == "ERR_PB_1412":
                    Script.notify("Network Error",
                                  "Use Jio network to play this content")
            else:
                Script.notify("Invalid Response", "{0}: Invalid response from server".format(
                    e.response.status_code))
            return False
        else:
            Script.log("{0}: Got unexpected response for request url {1}".format(
                e.__class__.__name__, url), lvl=Script.DEBUG)
            Script.notify(
                "API Error", "Raise issue if you are continuously facing this error")
            raise e

    def _refreshToken(self):
        try:
            with PersistentDict("userdata.pickle") as db:
                oldToken = db.get("token")
                if oldToken:
                    resp = self.session.get(url_constructor("/um/v3/users/refresh"),
                                            headers=self._getPlayHeaders(includeST=True, includeUM=False, extra={"x-hs-device-id": self.device_id, "x-request-id": self.device_id}), raise_for_status=False, max_age=-1).json()
                    if resp.get("errorCode"):
                        return resp.get("message")
                    new_token = deep_get(resp, "user_identity")
                    db['token'] = new_token
                    db.flush()
                    return new_token
            return False
        except Exception as e:
            return e

    @staticmethod
    def _getPlayHeaders(includeST=False, includeUM=False, playbackUrl=None, extra={}):
        with PersistentDict("userdata.pickle") as db:
            token = db.get("token")

        auth = getAuth(includeST, False, includeUM)
        headers = {
            "hotstarauth": auth,
            "x-hs-platform": "firetv",
            "x-hs-appversion": "7.41.0",
            "content-type": "application/json",
            "x-country-code": HotstarAPI.country,
            "x-platform-code": "PCTV",
            "x-hs-usertoken": token,
            "x-hs-request-id": HotstarAPI.device_id,
            "user-agent": "Hotstar;in.startv.hotstar/3.3.0 (Android/8.1.0)",
            # Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36
            **extra,
        }
        if playbackUrl:
            r = Request(playbackUrl)
            r.add_header("user-agent", headers.get("user-agent"))
            cookie = urlopen(r).headers.get("Set-Cookie", "").split(";")[0]
            if cookie:
                headers["Cookie"] = cookie
        return headers

    @staticmethod
    def _getPlayParams(subTag="", encryption="widevine"):
        with PersistentDict("userdata.pickle") as db:
            deviceId = db.get("deviceId", HotstarAPI.device_id)
        return {
            "device-id": deviceId,
            # "desired-config": "audio_channel:stereo|container:fmp4|dynamic_range:sdr|encryption:%s|ladder:phone|package:dash|resolution:fhd|%svideo_codec:h264" % (encryption, subTag or "")
            "desired-config": "ads:non_ssai|audio_channel:stereo|container:ts|dvr:short|dynamic_range:sdr|encryption:plain|ladder:web|language:hin|package:hls|resolution:fhd|video_codec:h264"
        }

    @staticmethod
    def _findPlayback(playBackSets, lang=None, ask=False):
        selected = None
        index = -1
        options = []
        quality = {"4k": 0, "hd": 1, "sd": 2}
        # 
        for each in playBackSets:
            config = {k: v for d in map(lambda x: dict([x.split(":")]), each.get(
                "tags_combination", "a:b").split(";")) for k, v in d.items()}
            #Script.log(
            #    f"Checking combination {config} with language {lang}", lvl=Script.DEBUG)
            if config.get("encryption", "") in ["plain", "widevine"] and config.get("package", "") in ["hls", "dash"]:
                if lang and config.get("language") and config.get("language", "") != lang:
                    continue
                config["playback"] = (each.get("playback_url"), each.get(
                    "licence_url"), "mpd" if config.get("package") == "dash" else "hls")
                config["Ext"] = each.get("playback_url").split('?')[0].split('/')[-1]
                if selected is None:
                    selected = config["playback"]
                if config.get("ladder"):
                    del config["ladder"]
                if config not in options:
                    options.append(config)
        options.sort(key=lambda x: str(
            quality.get(x.get("resolution", "sd")) or ""))
        if len(options) > 0:
            if Settings.get_string("playback_select") == "Ask" or ask:
                index = xbmcgui.Dialog().select("Playback Quality", list(map(lambda x: "Video: {0} - {1} - {2} - {3} | Audio: {4} - {5} | {6}".format(x.get("Ext", "").upper(), x.get(
                    "dynamic_range", "").upper(), x.get("video_codec", "").upper(), x.get("container", "").upper(), x.get("audio_channel", "").upper(), x.get("audio_codec", "").upper(), "Non-DRM" if x.get("encryption", "plain") == "plain" else "DRM"), options)))
                if index == -1:
                    return (None, None, None)
            else:
                options = list(filter(qualityFilter, options))
                if len(options) > 0:
                    index = 0
        if len(options) > 0:
            Script.log("Selected Config {0}".format(options[index]))
            selected = options[index].get("playback")
        if selected is None:
            selected = (playBackSets[0].get("playbackUrl"), playBackSets[0].get(
                "licenceUrl"), "hls" if ".m3u8" in playBackSets[0].get("playbackUrl") else "mpd")
            Script.log("No stream found for desired config. Using %s" %
                       playBackSets[0].get("playbackUrl"), lvl=Script.INFO)
        return selected
