﻿# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from datetime import datetime
from codequick import Listitem, Script, Resolver, Route
from codequick.storage import PersistentDict
import inputstreamhelper
from .contants import MEDIA_TYPE, BASE_HEADERS, url_api, url_content
from .api import deep_get, jiocinemaAPI
from .utils import updateQueryParams
from urllib.parse import urlencode
from pickle import dumps
from binascii import hexlify
import urlquick
import re
import web_pdb


class Builder:
    def buildMenu(self, menuItems):
        
        for each in menuItems:
            item = Listitem()
            item.label = each.get("name")
            # item.art['fanart'] = "https://secure-media.hotstar.com/static/firetv/v1/poster_%s_in.jpg" % each.get(
            #     "name").lower() if not each.get("name").lower() == "genres" else "https://secure-media.hotstar.com/static/firetv/v1/poster_genre_in.jpg"

            item.set_callback(Route.ref("/resources/lib/main:menu_list"), url=url_api("/user/v1/screen/personalized/%s" % each.get("homeId")), xpage=each.get("x-page"))
            # params = {
            #    "x-page": each.get("x-page")
            # }
            # item.params = params
            # aitem.params['x-page'] = each.get("x-page")
            # item.art.local_thumb(each.get("name").lower() + ".png")
            yield item

    def buildLanguageMovies(self):
        return Listitem.from_dict(Route.ref("/resources/lib/main:language_list"), "Movies By Language")

    def buildLanguage(self, menuItems):
        for lang, val in menuItems:
            item = Listitem()
            item.label = lang
            item.set_callback(Route.ref("/resources/lib/main:tray_list"), url=url_content("search/v1/langgenre?pageNo=0"), search_query=lang, categorytype="movie")
            # params = {
            #    "search_query": lang
            # }
            # item.params = params
            # aitem.params['x-page'] = each.get("x-page")
            # item.art.local_thumb(each.get("name").lower() + ".png")
            yield item

    def buildSearch(self, callback):
        return Listitem().search(callback, url="")

    def buildSettings(self):
        return Listitem.from_dict(Route.ref("/resources/lib/main:settings"), "Settings")

    def buildPage(self, items):

        for each in items:
            art = info = None

            info = {
                "plot": each.get("description")
            }
            art = {
                "thumb": each.get("image"),
                "icon": each.get("image"),
                "poster": each.get("banner"),
                "fanart": each.get("carousalImgUrl"),
            }

            tray_url = url_content("/screen/v1/category/%s?pageNo=0" % each.get("categoryId"))

            yield Listitem().from_dict(**{
                "label": each.get("title"),
                "art": art,
                "info": info,
                "callback": Route.ref("/resources/lib/main:tray_list"),
                "properties": {
                    "IsPlayable": False
                },
                "params": {
                    "url": tray_url,
                    "categorytype": each.get("categoryType")
                }
            })

    def buildTray(self, items, nextPageUrl=None, languages=None, categorytype=None):
        for eachItem in items:
            yield Listitem().from_dict(**self._buildItem(eachItem))
        if nextPageUrl:
            yield Listitem().next_page(url=nextPageUrl, search_query=languages, categorytype=categorytype)

    def buildPlay(self, playbackUrl, licenceUrl=None, playbackProto="mpd", label="", drm=False):
        is_helper = inputstreamhelper.Helper("mpd", drm=drm)
        if is_helper.check_inputstream():
            stream_headers = BASE_HEADERS
            """
            subtitleUrl = re.sub(
                "(.*)(master[\w+\_\-]*?\.[\w+]{3})([\w\/\?=~\*\-]*)", "\g<1>subtitle/lang_en/subtitle.vtt\g<3>", playbackUrl) + "|User-Agent=Hotstar%3Bin.startv.hotstar%2F3.3.0+%28Android%2F8.1.0%29"
            Script.log(subtitleUrl, lvl=Script.DEBUG)
            # subtitleUrl = 'https://hses4.hotstar.com/videos/hotstar/blackpanther/1660010672/1611647161705/1bad5004c092bd7b1df930cf34f1c73b/subtitle/lang_eng/subtitle.vtt'
            """
            if licenceUrl:
                drm = "com.widevine.alpha"
            return Listitem().from_dict(**{
                "label": label,
                "callback": playbackUrl,
                "properties": {
                    "IsPlayable": True,
                    "inputstream": is_helper.inputstream_addon,
                    "inputstream.adaptive.manifest_type": playbackProto,
                    "inputstream.adaptive.license_type": drm,
                    # "inputstream.adaptive.stream_headers": urlencode(stream_headers),
                    "inputstream.adaptive.license_key": '%s|Content-Type=&%s|R{SSM}|' % (licenceUrl, urlencode(stream_headers)),
                    "inputstream.adaptive.max_bandwidth": '1000000'
                },
                # "subtitles": [subtitleUrl]
            })
        return False

    def _buildItem(self, item):
        # web_pdb.set_trace()
        if item.get("contentType") in ["Show"]:
            callback = Route.ref("/resources/lib/main:tray_list")
            url = url_content("/metadata/v2/metadata/Show/%s" % item.get("contentId"))
            params = {
                "url": url,
                "categorytype": "show"
            }
        else:
            callback = Resolver.ref("/resources/lib/main:play_vod")
            params = {
                "contentId": item.get("contentId"),
                "label": item.get("name")
            }

        if item.get("contentType") in ["Episode"]:
            # label = "S%sE%s" % (item.get("season"), item.get("episodeNo"))
            label = item.get("subtitle")
        else:
            label = item.get("name")
        """
        if item.get("clipType", "") == "LIVE":
            label += "  -  [COLOR red]LIVE[/COLOR]"
        elif item.get("assetType") == "SEASON":
            label = "Season {0} ({1})".format(
                item.get("seasonNo"), item.get("episodeCnt"))


        if item.get("watched"):
            props["ResumeTime"] = item.get(
                "watched", 0) * item.get("duration", 0)
            props["TotalTime"] = item.get("duration", 0)
        """
        props = {"IsPlayable": False}
        if item.get("portraitImg"):
            poster = item.get("portraitImg") if item.get("portraitImg").startswith("http") else 'https://jcimages.cdn.jio.com/imagespublic/' + item.get("portraitImg")
        else:
            poster = item.get("image") if item.get("image").startswith("http") else 'https://jcimages.cdn.jio.com/imagespublic/' + item.get("image")

        return {
            "label": label,
            "art": {
                "icon": item.get("image") if item.get("image").startswith("http") else 'https://jcimages.cdn.jio.com/imagespublic/' + item.get("image"),
                "thumb": item.get("image") if item.get("image").startswith("http") else 'https://jcimages.cdn.jio.com/imagespublic/' + item.get("image"),
                "fanart": item.get("carousalImgUrl") if item.get("carousalImgUrl").startswith("http") else 'https://jcimages.cdn.jio.com/imagespublic/' + item.get("carousalImgUrl"),
                "poster": poster
            },
            "info": {
                "genre": item.get("genres"),
                "episode": item.get("episodeNo"),
                "season": item.get("season"),
                "mpaa": item.get("maturityRating"),
                "plot": item.get("description"),
                # "setCast": item.get("starcastDetail"),
                "cast": item.get("starcast"),
                "title": label,
                "tvshowtitle": label if item.get("contentType")=='Show' else None,
                "duration": item.get("totalDuration"),
                "studio": item.get("vendor"),
                "mediatype": MEDIA_TYPE.get(item.get("contentType"))
            },
            "properties": props,
            # TODO: Get Stream Info
            # "stream": {
            #     # "video_codec": "h264",
            #     "width": "1920",
            #     "height": "1080",
            #     # "audio_codec": "aac"
            # },
            "callback": callback,
            "params": params
        }
