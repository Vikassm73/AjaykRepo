﻿# -*- coding: utf-8 -*-
from codequick.utils import urljoin_partial
from codequick.script import Settings
import collections


NAME = "plugin.video.jiocinema"

# URLs
API_BASE_URL = "https://apis-jiocinema.voot.com"
CONTENT_URL = 'https://content-jiocinema.voot.com'
IMG_BASE = "https://img1.hotstar.com/image/upload"
IMG_FANART_H_URL = IMG_BASE + "/f_auto,w_1920,h_1080/%s.jpg"
IMG_POSTER_V_URL = IMG_BASE + "/f_auto,t_web_vl_3x/%s.jpg"
IMG_THUMB_H_URL = IMG_BASE + "/f_auto,t_web_hs_3x/%s.jpg"

#BASE_HEADERS = {
#    "x-apisignatures": "o668nxgzwff",
#    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36"}

ssotoken = "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7InVzZXJUeXBlIjoiR1VFU1QiLCJhcHBOYW1lIjoiUkpJTF9KaW9DaW5lbWEiLCJkZXZpY2VJZCI6IjE4NTQ3OTA2NDMiLCJkZXZpY2VUeXBlIjoicGhvbmUiLCJvcyI6ImlvcyJ9LCJleHAiOjE3MDMyMzY5MDgsImlhdCI6MTY3MTcwMDkwOH0.-wL9u4G-1VZ37nGiC2SIs31j-0bRfx7vXx62phCYQqgk4j-1t_qHBgbLg6yhYy8Rix6P254TNOStdr2UTYJeeA"
BASE_HEADERS = {
    'os': 'Android',
    'devicetype': 'stb',
    # 'user-agent': 'JioOnDemand/1.5.2.1 (Linux;Android 4.4.2) Jio',
    # 'accept': 'application/json, text/plain, */*',
    # 'Content-Type': 'application/json',
    # 'Referer': 'https://www.jiocinema.com/',
    # 'origin': 'https://www.jiocinema.com',
    'ssotoken': ssotoken,
    'uniqueid': '1854790643',
    'usergroup': '39ee6ded40812c593ed8',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
    'x-apisignatures': 'o668nxgzwff'
}

CONTENT_TYPE = {"Movie": "movies", "Show": "tvshows",
                "Video": "videos", "Episode": "episodes"}
MEDIA_TYPE = {"Movie": "movie", "Show": "tvshow",
              "Video": "video", "Episode": "episode"}

url_content = urljoin_partial(CONTENT_URL)
url_api = urljoin_partial(API_BASE_URL)
