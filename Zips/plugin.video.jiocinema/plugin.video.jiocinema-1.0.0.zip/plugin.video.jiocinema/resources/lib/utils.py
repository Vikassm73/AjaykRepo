from functools import wraps, reduce
from codequick import Script
from codequick.script import Settings
from codequick.storage import PersistentDict
from .contants import url_api, BASE_HEADERS
from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse
import urlquick
import json
from uuid import uuid4
import time
import hashlib
import hmac


def deep_get(dictionary, keys, default=None):
    return reduce(lambda d, key: d.get(key, default) if isinstance(d, dict) else default, keys.split("."), dictionary)


def isLoggedIn(func):
    """
    Decorator to ensure that a valid login is present when calling a method
    """
    @wraps(func)
    def login_wrapper(*args, **kwargs):
        with PersistentDict("userdata.pickle") as db:
            if db.get("token"):
                return func(*args, **kwargs)
            elif db.get("isGuest") is None:
                # token ='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJ1bV9hY2Nlc3MiLCJleHAiOjE2NzA5OTY3NzksImlhdCI6MTY3MDkxMDM3OSwiaXNzIjoiVFMiLCJqdGkiOiIyY2E4MjIyYjJkNzE0ZjEzODc1ZTQzNThlOWM4MGE0OSIsInN1YiI6IntcImhJZFwiOlwiMThhNTVkZmRhMTM1NGJhYTk0NjRmYTk1NDhhYzczOThcIixcInBJZFwiOlwiYTA0NGM0ZDU5NTM2NGM0NGI1MjI1OGIyZmFkZjM5Y2ZcIixcIm5hbWVcIjpcIktpcmFuIEt1bWFyXCIsXCJwaG9uZVwiOlwiOTg4NDMzOTY3N1wiLFwiaXBcIjpcIjI0MDU6MjAxOmUwMzY6NTgwNzpjZjQ6YTMwNzoyYTk5OmVlMTVcIixcImNvdW50cnlDb2RlXCI6XCJpblwiLFwiY3VzdG9tZXJUeXBlXCI6XCJudVwiLFwidHlwZVwiOlwicGhvbmVcIixcImlzRW1haWxWZXJpZmllZFwiOmZhbHNlLFwiaXNQaG9uZVZlcmlmaWVkXCI6dHJ1ZSxcImRldmljZUlkXCI6XCI5NTE5OWEwYi1jODVhLTQwNTUtYmE4MS1hZDcyNGUwNTk5MTNcIixcInByb2ZpbGVcIjpcIkFEVUxUXCIsXCJ2ZXJzaW9uXCI6XCJ2MlwiLFwic3Vic2NyaXB0aW9uc1wiOntcImluXCI6e1wiSG90c3RhckJ1bmRsZVwiOntcInN0YXR1c1wiOlwiU1wiLFwiZXhwaXJ5XCI6XCIyMDIzLTAxLTAyVDEwOjI5OjU5LjAwMFpcIixcInNob3dBZHNcIjpcIjFcIixcImNudFwiOlwiMVwifSxcIkhvdHN0YXJTdXBlclwiOntcInN0YXR1c1wiOlwiU1wiLFwiZXhwaXJ5XCI6XCIyMDIzLTAyLTI1VDE4OjM3OjI5LjAwMFpcIixcInNob3dBZHNcIjpcIjFcIixcImNudFwiOlwiMVwifX19LFwiZW50XCI6XCJDc2tCQ2dVS0F3b0JCUksvQVJJSFlXNWtjbTlwWkJJRGFXOXpFZ2xoYm1SeWIybGtkSFlTQm1acGNtVjBkaElIWVhCd2JHVjBkaElFY205cmRSSURkMlZpRWdSdGQyVmlFZ2QwYVhwbGJuUjJFZ1YzWldKdmN4SUdhbWx2YzNSaUVncGphSEp2YldWallYTjBFZ1IwZG05ekVnUndZM1IyRWdOcWFXOFNCMnBwYnkxc2VXWWFBbk5rR2dKb1pCb0RabWhrSWdOelpISWlCV2hrY2pFd0lndGtiMnhpZVhacGMybHZiaW9HYzNSbGNtVnZLZ2hrYjJ4aWVUVXVNU29LWkc5c1lubEJkRzF2YzFnQkNnMFNDd2htT0FoQUFWQzRDRmdCQ2lJS0dnb09FZ1UxTlRnek5oSUZOalF3TkRrS0NDSUdabWx5WlhSMkVnUTRaRmdCQ3NrQkNnVUtBd29CQUJLL0FSSUhZVzVrY205cFpCSURhVzl6RWdsaGJtUnliMmxrZEhZU0JtWnBjbVYwZGhJSFlYQndiR1YwZGhJRWNtOXJkUklEZDJWaUVnUnRkMlZpRWdkMGFYcGxiblIyRWdWM1pXSnZjeElHYW1sdmMzUmlFZ3BqYUhKdmJXVmpZWE4wRWdSMGRtOXpFZ1J3WTNSMkVnTnFhVzhTQjJwcGJ5MXNlV1lhQW5Oa0dnSm9aQm9EWm1oa0lnTnpaSElpQldoa2NqRXdJZ3RrYjJ4aWVYWnBjMmx2YmlvR2MzUmxjbVZ2S2doa2IyeGllVFV1TVNvS1pHOXNZbmxCZEcxdmMxZ0JFZ2tJQVJEWTBKK1ExekE9XCIsXCJpc3N1ZWRBdFwiOjE2NzA5MTAzNzk5MDV9IiwidmVyc2lvbiI6IjFfMCJ9.tZmpTtoZXxfzKvrPWsP-6twBpGr_WI2OpnRWWrj1jBw'
                # db["token"] = token
                db["token"] = guestToken()
                db["isGuest"] = True
                db.flush()
                return func(*args, **kwargs)
            else:
                # login require
                Script.notify(
                    "Login Error", "You need valid subscription to watch this content")
                # xbmc.executebuiltin(
                #    "RunPlugin(plugin://plugin.video.botallen.hotstar/resources/lib/main/login/)")
                return False
    return login_wrapper

def guestToken():
    headers = BASE_HEADERS
    data = {"deviceType": "pc", "os": "web", "appName": "RJIL_JioCinema", "deviceId": "1854790643"}
    data = json.dumps(data)

    resp = urlquick.post("https://auth-jiocinema.voot.com/tokenservice/apis/v2/guest",
                         data=data, headers=headers).json()

    return deep_get(resp, "authToken")


def updateQueryParams(url, params):
    url_parts = list(urlparse(url))
    query = dict(parse_qsl(url_parts[4]))
    query.update(params)
    url_parts[4] = urlencode(query)
    return urlunparse(url_parts)


def qualityFilter(config):
    return (
        config.get("resolution", "hd") == ["4k", "hd", "sd"][Settings.get_int("resolution")] and
        config.get("video_codec", "h265") == ["dvh265", "h265", "vp9", "h264"][Settings.get_int("video_codec")] and
        config.get("dynamic_range", "sdr") == ["dv", "hdr10", "sdr"][Settings.get_int("dynamic_range")] and
        config.get("audio_channel", "stereo") == ["stereo", "dolby51"][Settings.get_int("audio_channel")] and
        config.get("audio_codec", "aac") == [
            "ec3", "aac"][Settings.get_int("audio_codec")]
    )
