﻿# -*- coding: utf-8 -*-shToken
from __future__ import unicode_literals

import urlquick
# from kodi_six import xbmc, xbmcaddon, xbmcplugin, xbmcgui
from xbmcgui import Dialog
# import xbmc
from functools import wraps, reduce
from resources.lib.contants import BASE_HEADERS, url_content, url_api
from resources.lib.utils import deep_get, guestToken
from codequick import Script
from codequick.script import Settings
from codequick.storage import PersistentDict
from codequick.utils import keyboard
from urllib.parse import quote_plus
from urllib.request import urlopen, Request
import json
from uuid import uuid4
from base64 import b64decode, b64encode
import web_pdb


class jiocinemaAPI:

    def __init__(self):
        self.session = urlquick.Session()
        self.session.headers.update(BASE_HEADERS)

    def getMenu(self, language=False):
        url = url_content("/config/v2")
        resp = self.get(
            url, headers=BASE_HEADERS, max_age=-1)
        if language:
            return deep_get(resp, "data.languageAndCode.m3u8")
        else:
            return deep_get(resp, "data.sliderDynamic")

    def getPage(self, url, xpage):
        headers = BASE_HEADERS
        headers.update({"x-page": xpage})
        results = deep_get(self.get(url, headers=headers), "data")

        return results

    def getTray(self, url, search_query=None, categorytype=None):
        headers = BASE_HEADERS
        if search_query:
            if url == "":
                url = url_content("/search/v1/search?q=%s" % quote_plus(search_query))
                headers.update({"x-page": "Search"})
                results = self.get(url, headers=headers)
            else:
                headers.update({"x-page": "LangGenre"})
                data = {"languages": [search_query], "genres": ["All Genres"], "contentType": "Movie", "sort": "NewToOld", "langGenreType": "language"}
                data = json.dumps(data)
                results = self.post(url, headers=headers, data=data)
        else:
            headers.update({"x-page": "Home"})
            results = self.get(url, headers=headers)


        """
        if "items" in results:
            results = results.get("items")
            if "progress_meta" in results and type(results.get("items")) is dict:
                for cID, data in results.get("progress_meta").items():
                    results["items"][cID].update(data)
        else:

        results = deep_get(results, "data.items")

        if results:
            items = results.get("items") or deep_get(results, "assets.items") or (results.get(
                "map") and list(results.get("map").values())) or deep_get(results, "trays.items") or []
            if type(items) is dict:
                items = list(items.values())
            nextPageUrl = deep_get(
                results, "assets.nextOffsetURL") or results.get("nextOffsetURL")

            totalResults = deep_get(
                results, "assets.totalResults") or results.get("totalResults")
            allResultsPageUrl = None
            if len(items) > 0 and nextPageUrl is not None and ("/season/" in nextPageUrl or items[0].get("assetType") == "EPISODE") and totalResults is not None:
                allResultsPageUrl = updateQueryParams(nextPageUrl, {"size": str(
                    totalResults), "tas": str(totalResults), "offset": "0"})

            if deep_get(results, "channelClip.clipType", "") == "LIVE":
                items.insert(0, deep_get(results, "channelClip", {}))

            return items, nextPageUrl, allResultsPageUrl
        """
        if categorytype == 'show':
            results = deep_get(results, "data.categories")
        else:
            results = deep_get(results, "data")

        if results:
            if json.dumps(results).startswith("["):
                results = results[0]
            items = results.get("items")
            x = url.split("=")
            if categorytype == 'movie':
                totalpages = results.get("pageCount") if results.get("pageCount") else results.get("totalPages")
                page = int(x[1]) + 1
            else:
                page = 0
                totalpages = 0

            if totalpages > page:
                nextPageUrl = x[0] + "=" + str(page)
            else:
                nextPageUrl = None
            return items, nextPageUrl
        return [], None, None

    def getPlayold(self, contentId, drm=False, lang=None, ask=False):

        url = url_api("/playback/v1/%s" % (contentId))
        headers = BASE_HEADERS
        # headers.update({'Content-Type': 'application/json'})
        # headers.update({'uniqueid': '2664423931'})
        
        data = '{"bitrateProfile": "xhdpi","multiAudioRequired": true}'
        resp = self.post(url, headers=headers, data=data, max_age=-1)
        playBackSets = deep_get(resp, "data.mpd")
        licenceUrl = None
        playbackProto = 'mpd'

        if playBackSets is None:
            return None, None, None
        playbackUrl = deep_get(playBackSets, Settings.get_string("playback_select")) + "?jct=" + deep_get(resp, "data.jct") + "&pxe=" + deep_get(resp, "data.pxe") + "&st=" + deep_get(resp, "data.st")
        licenceUrl = resp['data'].get("keyURL") + "&jct=" + deep_get(resp, "data.jct") + "&pxe=" + deep_get(resp, "data.pxe") + "&st=" + deep_get(resp, "data.st")
        return playbackUrl, licenceUrl, playbackProto

    def getPlay(self, contentId, drm=False, lang=None, ask=False):

        url = url_api("/playbackjv/v2/%s" % (contentId))
        hdr = BASE_HEADERS
        hdr.update({"Content-Type": BASE_HEADERS.get('application/json')})

        # web_pdb.set_trace()
        # self.refreshToken()

        data = '{"bitrateProfile":"xhdpi","multiAudioRequired":true,"kidsSafe":false,"parentalPinValid":false,"4k":false,"hevc":false,"dolby":false,"x-apisignatures":"o668nxgzwff","ageGroup":"3+","continueWatchingRequired":false,"manufacturer":"Windows","model":"Windows","appVersion":"3.4.0","osVersion":"10","capability":{"frameRateCapability":[{"videoQuality":"1440p","frameRateSupport":"30fps"}],"drmCapability":{"widevineDRMSupport":"yes","playreadyDrmSupport":"none","fairPlayDrmSupport":"none","aesSupport":"yes"}},"downloadRequest":false}'
        resp = self.post(url, headers=hdr, data=data)
        playBackSets = deep_get(resp, "data.mpd.bitrates")
        licenceUrl = None
        playbackProto = 'mpd'

        if playBackSets is None:
            return None, None, None
        playbackUrl = deep_get(playBackSets, Settings.get_string("playback_select"))
        licenceUrl = deep_get(resp, "data.mpd.key")
        return playbackUrl, licenceUrl, playbackProto

    def doLogin(self):
        mobile = Settings.get_string("mobile")
        if mobile is None:
            mobile = Dialog().numeric(0, "Enter 10 Digit mobile number")
        # mobile = keyboard("Enter your Jio mobile number")
        # headers = BASE_HEADERS
        headers = BASE_HEADERS
        headers.update({'os': 'android'})
        headers.update({'devicetype': 'phone'})
        headers.update({'Content-Type': 'application/json'})
        headers.update({"appname": 'RJIL_JioCinema'})
        # headers.update({'usergroup': '39ee6ded40812c593ed8'})
        # headers.update({'x-apisignatures': '993dcd07659'})
        # headers.update({'x-feature-code': 'ytvjywxwkn'})
        # headers.update({'x-token-platform': 'Web'})

        url = 'https://auth-jiocinema.voot.com/userservice/apis/v1/loginotp/send'

        mobileEncode = str(b64encode(('+91' + mobile).encode("ascii")), 'UTF-8')
        data = '{"number": "' + mobileEncode + '"}'

        resp = urlquick.post(url, headers=headers, data=data, max_age=-1)
        if resp.status_code == 204:
            OTP = Dialog().numeric(0, "Enter 6 Digit OTP")
            url = "https://auth-jiocinema.voot.com/userservice/apis/v1/loginotp/verify"
            data = '{"number": "' + mobileEncode + '","otp": "' + OTP + '","deviceInfo":{"consumptionDeviceName":"iPhone","info":{"platform":{"name":"iPhone OS"},"androidId":"E31BF81FC74E480E8E9C23AA96A80B68","type":"iOS"}}}'
            # data = json.dumps(data)
            # headers.update({'os': 'web'})
            # headers.update({'devicetype': 'pc'})
            resp = self.post(url, headers=headers, data=data, max_age=-1)
            Script.log(resp, lvl=Script.INFO)
            if resp:
                with PersistentDict("userdata.pickle") as db:
                    db.clear()
                    db["authtoken"] = resp.get("authToken")
                    db["ssotoken"] = resp.get("ssoToken")
                    db["uniqueID"] = deep_get(resp, "sessionAttributes.user.unique")
                    db["UserType"] = "JIOUSER"
                    db.flush()
                    BASE_HEADERS.update({"accesstoken": resp.get("authToken")})
                    BASE_HEADERS.update({"ssotoken": resp.get("ssoToken")})
                    BASE_HEADERS.update({"uniqueid": deep_get(resp, "sessionAttributes.user.unique")})
                    Script.notify("Login Success", "You are logged in")
            else:
                Script.notify("Login Faild", "Login Failed..")

    def doLoginOld(self):
        mobile = Dialog().numeric(0, "Enter 10 Digit mobile number")
        # mobile = keyboard("Enter your Jio mobile number")
        # headers = BASE_HEADERS

        headers = {
            'authority': 'prod.media.jio.com',
            'pragma': 'no-cache',
            'cache-control': 'no-cache',
            'origin': 'https://www.jiocinema.com',
            'referer': 'https://www.jiocinema.com/',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'
        }

        headers.update({"deviceId": '1854790643'})
        
        url = 'https://prod.media.jio.com/apis/common/v3/login/sendotp'
        
        data = '{"number":"+91' + mobile + '"}'
        # data = json.dumps(data)
        # 
        resp = self.post(url, headers=headers, data=data)
        if resp:
            OTP = Dialog().numeric(0, "Enter 6 Digit OTP")
            url = url_api(
                "/um/v3/users/login?login-by=phone_otp")
            url = "https://prod.media.jio.com/apis/common/v3/login/verifyotp"
            data = '{"number":"+91' + mobile + '","otp":"' + OTP + '"}'
            # data = json.dumps(data)
            resp = self.post(url, headers=headers, data=data)
            Script.log(resp, lvl=Script.INFO)
            if resp:
                with PersistentDict("userdata.pickle") as db:
                    db["ssotoken"] = resp.get("ssotoken")
                    db["uniqueID"] = resp.get("uniqueId")
                    db["UserType"] = "JIOUSER"
                    db.flush()
                    Script.notify("Login Success", "You are logged in")
            else:
                Script.notify("Login Faild", "Login Failed..")

    def doLogout(self):
        with PersistentDict("userdata.pickle") as db:
            db.clear()
            db.flush()

        Script.notify("Logout Success", "You are logged out")
        return False

    def get(self, url, **kwargs):
        try:
            response = self.session.get(url, **kwargs)
            return response.json()
        except Exception as e:
            return self._handleError(e, url, "get", **kwargs)

    def post(self, url, **kwargs):
        try:
            response = self.session.post(url, **kwargs)
            return response.json()
        except Exception as e:
            return self._handleError(e, url, "post", **kwargs)

    def put(self, url, **kwargs):
        try:
            response = self.session.put(url, **kwargs)
            # xbmc.log(json.dumps(response.json()))
            return response.json()
        except Exception as e:
            return self._handleError(e, url, "put", **kwargs)

    def _handleError(self, e, url, _rtype, **kwargs):
        # web_pdb.set_trace()
        if e.__class__.__name__ == "ValueError":
            Script.log("Can not parse response of request url %s" %
                       url, lvl=Script.DEBUG)
            Script.notify("Internal Error", "")
        elif e.__class__.__name__ == "HTTPError":
            if e.response.status_code == 402 or e.response.status_code == 403:
                with PersistentDict("userdata.pickle") as db:
                    if db.get("UserType") == "GUEST":
                        Script.notify(
                            "Subscription Error", "Please subscribe to watch this content")
                        # xbmc.executebuiltin(
                        #    "RunPlugin(plugin://plugin.video.botallen.hotstar/resources/lib/main/login/)")
                    else:
                        Script.notify(
                            "Subscription Error", "You don't have valid subscription to watch this content", display_time=2000)
            elif e.response.status_code == 500 or e.response.status_code == 419:
                with PersistentDict("userdata.pickle") as db:
                    if db.get("UserType") == "GUEST":
                        guestToken()
                    else:
                        self.doLogin()

                    if _rtype == "get":
                        return self.get(url, **kwargs)
                    else:
                        return self.post(url, **kwargs)

            elif e.response.status_code == 474 or e.response.status_code == 475:
                Script.notify(
                    "VPN Error", "Your VPN provider does not support Hotstar")
            elif e.response.status_code == 404 and e.response.headers.get("Content-Type") == "application/json":
                if e.response.json().get("errorCode") == "ERR_PB_1412":
                    Script.notify("Network Error",
                                  "Use Jio network to play this content")
            else:
                Script.notify("Invalid Response", "{0}: Invalid response from server".format(
                    e.response.status_code))
            return False
        else:
            Script.log("{0}: Got unexpected response for request url {1}".format(
                e.__class__.__name__, url), lvl=Script.DEBUG)
            Script.notify(
                "API Error", "Raise issue if you are continuously facing this error")
            raise e

    def refreshToken(self):
        try:
            with PersistentDict("userdata.pickle") as db:
                oldToken = db.get("ssotoken")
                if oldToken:
                    headers = BASE_HEADERS
                    headers.update({'Content-Type': 'application/json'})
                    headers.update({'appkey': '06758e99be484fca56fb'})

                    url = 'https://prod.media.jio.com/apis/common/v3/accesstoken/get'
                    resp = self.session.post(url, headers=headers, max_age=-1).json
                    if resp.get("errorCode"):
                        return resp.get("message")
                    new_token = deep_get(resp, "user_identity")
                    db['token'] = new_token
                    db.flush()
                    return new_token
            return False
        except Exception as e:
            return e
