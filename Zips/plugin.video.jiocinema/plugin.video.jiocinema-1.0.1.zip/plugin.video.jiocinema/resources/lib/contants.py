﻿# -*- coding: utf-8 -*-
from codequick.utils import urljoin_partial
from codequick.script import Settings
import collections


NAME = "plugin.video.jiocinema"

# URLs
API_BASE_URL = "https://apis-jiocinema.voot.com"
CONTENT_URL = 'https://content-jiocinema.voot.com'
IMG_BASE = 'https://jcimages.cdn.jio.com/imagespublic/'


BASE_HEADERS = {
    'Accept': 'application/json, text/plain, */*',
    'Referer': 'https://www.jiocinema.com/',
    "x-apisignatures": "o668nxgzwff",
    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36"}

"""
BASE_HEADERS = {
    'os': 'android',
    'devicetype': 'phone',
    # 'user-agent': 'JioOnDemand/1.5.2.1 (Linux;Android 4.4.2) Jio',
    # 'accept': 'application/json, text/plain, */*',
    # 'Content-Type': 'application/json',
    'Referer': 'https://www.jiocinema.com/',
    # 'origin': 'https://www.jiocinema.com',
    # 'ssotoken': ssotoken,
    # 'uniqueid': '2664423931',
    'usergroup': '39ee6ded40812c593ed8',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
    'x-apisignatures': '993dcd07659',
    'x-feature-code': 'ytvjywxwkn',
    'x-token-platform': 'Web'
}
"""
CONTENT_TYPE = {"Movie": "movies", "Show": "tvshows",
                "Video": "videos", "Episode": "episodes"}
MEDIA_TYPE = {"Movie": "movie", "Show": "tvshow",
              "Video": "video", "Episode": "episode"}

url_content = urljoin_partial(CONTENT_URL)
url_api = urljoin_partial(API_BASE_URL)