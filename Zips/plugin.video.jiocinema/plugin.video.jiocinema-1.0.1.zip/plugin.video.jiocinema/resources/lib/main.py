﻿# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from codequick import Route, run, Script, Resolver

import resources.lib.utils as U
from kodi_six import xbmc, xbmcaddon, xbmcplugin, xbmcgui
import six
# from xbmc import executebuiltin
# from xbmcplugin import SORT_METHOD_EPISODE, SORT_METHOD_DATE
from .api import jiocinemaAPI
from .builder import Builder
from .contants import CONTENT_TYPE
from .utils import guestToken


@Route.register
def root(plugin):
    yield builder.buildSearch(Route.ref("/resources/lib/main:tray_list"))
    menuItems = api.getMenu()
    yield from builder.buildMenu(menuItems)
    yield builder.buildLanguageMovies()
    yield builder.buildSettings()


@Route.register
def menu_list(plugin, url, xpage):
    items = api.getPage(url, xpage)
    yield from builder.buildPage(items)


@Route.register
def language_list(plugin):
    items = api.getMenu(True)
    yield from builder.buildLanguage(six.iteritems(items))


@Route.register
def tray_list(plugin, url, search_query=False, categorytype=None):

    items, nextPageUrl = api.getTray(
        url, search_query=search_query, categorytype=categorytype)

    if not items or len(items) == 0:
        yield False
        Script.notify("No Result Found", "No items to show")
        raise StopIteration()

    # plugin.content_type = CONTENT_TYPE.get(items[0].get("contentType"))
    # Script.notify("No Result Found", items[0].get("contentType"))
    if items[0].get("contentType") == "Show":
        plugin.content_type = None

    """
    if plugin.content_type == "episodes":
        plugin.add_sort_methods(SORT_METHOD_EPISODE)
        CONTENT_TYPE.get(items[0].get("assetType"))
    """
    yield from builder.buildTray(items, nextPageUrl, search_query, categorytype)


@Resolver.register
@U.isLoggedIn
def play_vod(plugin, contentId, label, drm=False, lang=None, ask=False):

    playbackUrl, licenceUrl, playbackProto = api.getPlayold(
        contentId, drm=drm, lang=lang, ask=ask)
    """
    index = xbmcgui.Dialog().select("Playback Options", ["Option 1", "Option 2"], preselect=0)

    if index == 0:
        playbackUrl, licenceUrl, playbackProto = api.getPlay(
            contentId, drm=drm, lang=lang, ask=ask)
    else:
        playbackUrl, licenceUrl, playbackProto = api.getPlayold(
            contentId, drm=drm, lang=lang, ask=ask)
    """
    if playbackUrl:
        return builder.buildPlay(playbackUrl, licenceUrl, playbackProto, label, drm)
    return False


@Script.register
def login(plugin):
    api.doLogin()


@Script.register
def logout(plugin):
    api.doLogout()
    return False


@Script.register
def settings(plugin):
    xbmc.executebuiltin("Addon.OpenSettings({0})".format(plugin.get_info("id")))
    return False


api = jiocinemaAPI()
builder = Builder()
