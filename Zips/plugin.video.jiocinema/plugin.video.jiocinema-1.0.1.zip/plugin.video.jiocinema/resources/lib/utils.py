from functools import wraps, reduce
from codequick import Script
from codequick.script import Settings
from codequick.storage import PersistentDict
from .contants import url_api, BASE_HEADERS
from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse
import urlquick
import json
from uuid import uuid4
import time
import hashlib
import hmac
import web_pdb
from base64 import b64decode


def deep_get(dictionary, keys, default=None):
    return reduce(lambda d, key: d.get(key, default) if isinstance(d, dict) else default, keys.split("."), dictionary)


def isLoggedIn(func):
    """
    Decorator to ensure that a valid login is present when calling a method
    """
    @wraps(func)
    def login_wrapper(*args, **kwargs):
        with PersistentDict("userdata.pickle") as db:
            if db.get("ssotoken"):
                if BASE_HEADERS.get("ssotoken") is None:
                    BASE_HEADERS.update({"accesstoken": db.get("authtoken")})
                    BASE_HEADERS.update({"ssotoken": db.get("ssotoken")})
                    BASE_HEADERS.update({"uniqueid": db.get("uniqueID")})
                return func(*args, **kwargs)
            elif db.get("UserType") is None:
                guestToken()
                return func(*args, **kwargs)
            else:
                # login require
                Script.notify(
                    "Login Error", "You need valid subscription to watch this content")
                # xbmc.executebuiltin(
                #    "RunPlugin(plugin://plugin.video.botallen.hotstar/resources/lib/main/login/)")
                return False
    return login_wrapper


def guestToken():
    # headers = BASE_HEADERS

    headers = {
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
        'Referer': 'https://www.jiocinema.com/',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
    }

    data = {"deviceType": "pc", "os": "web", "appName": "RJIL_JioCinema", "deviceId": "2664423931"}
    data = json.dumps(data)
    resp = urlquick.post("https://auth-jiocinema.voot.com/tokenservice/apis/v2/guest",
                         data=data, headers=headers).json()
    # Script.log(resp, lvl=Script.INFO)
    with PersistentDict("userdata.pickle") as db:
        db.clear()
        db["UserType"] = "GUEST"
        db["authtoken"] = deep_get(resp, "authToken")
        db["ssotoken"] = deep_get(resp, "authToken")
        db["uniqueID"] = deep_get(resp, "sessionAttributes.user.uniqueId")
        BASE_HEADERS.update({"ssotoken": deep_get(resp, "authToken")})
        BASE_HEADERS.update({"accesstoken": deep_get(resp, "authToken")})
        BASE_HEADERS.update({"uniqueid": deep_get(resp, "sessionAttributes.user.uniqueId")})
        db.flush()
    return
