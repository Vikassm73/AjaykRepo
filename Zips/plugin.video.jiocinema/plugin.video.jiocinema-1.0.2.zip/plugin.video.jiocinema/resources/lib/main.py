"""
    Voot Kodi Addon

"""

import sys
from kodi_six import xbmc, xbmcplugin, xbmcgui, xbmcaddon
import six
from six.moves import urllib_parse
import re
import requests
import math
import uuid
from codequick import Route, run, Script
from base64 import b64decode, b64encode
import web_pdb
from json import dumps
try:
    import StorageServer
except:
    import storageserverdummy as StorageServer

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

_addon = xbmcaddon.Addon()
_addonname = _addon.getAddonInfo('name')
_version = _addon.getAddonInfo('version')
_addonID = _addon.getAddonInfo('id')
_icon = _addon.getAddonInfo('icon')
_fanart = _addon.getAddonInfo('fanart')
_settings = _addon.getSetting

cache = StorageServer.StorageServer('jiocinema', _settings('timeout'))


# 
def doLogout():
    """
    Clear the cache database.
    """
    msg = 'Cached Data has been cleared'
    cache.table_name = 'jiocinema'
    cache.cacheDelete('%get%')
    _addon.setSetting("accesstoken", '')
    xbmcgui.Dialog().notification(_addonname, msg, _icon, 3000, False)


if _settings('version') != _version:
    _addon.setSetting('version', _version)
    doLogout()
    _addon.openSettings()

apiUrl = 'https://apis-jiovoot.voot.com/'
contentUrl = 'https://content-jiovoot.voot.com/psapi/voot/v1/voot-web'
iconUrl = 'https://v3img.voot.com/v3Storage/menu/'

headers = {'Accept': 'application/json, text/plain, */*',
           'Referer': 'https://www.jiocinema.com/',
           "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36"
           }


def guestToken():
    """
    headers = {
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
        'Referer': 'https://www.jiocinema.com/',
        'content-version': 'V6',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
    }
    """
    # web_pdb.set_trace()
    data = '{"appName":"RJIL_JioCinema","deviceType":"phone","os":"ios","deviceId":"3968183400","freshLaunch":false,"adId":"3968183400"}'
    resp = requests.post("https://auth-jiocinema.voot.com/tokenservice/apis/v4/guest",
                         data=data, headers=headers).json()
    # Script.log(resp, lvl=Script.INFO)

    _addon.setSetting("accesstoken", resp['authToken'])
    _addon.setSetting("deviceid", resp['deviceId'])
    _addon.setSetting("uniqueid", resp['userId'])

    headers.update({"accesstoken": resp['authToken']})
    headers.update({"deviceid": resp['deviceId']})
    headers.update({"uniqueid": resp['userId']})
    return


def doLogin():
    mobile = _addon.getSetting('mobile')

    hdr = headers
    hdr.update({'os': 'android'})
    hdr.update({'devicetype': 'phone'})
    hdr.update({'content-type': 'application/json'})
    hdr.update({"appname": 'RJIL_JioCinema'})

    # web_pdb.set_trace()
    if mobile:
        url = "https://auth-jiocinema.voot.com/userservice/apis/v4/loginotp/send"
        Pattern = re.compile("[6-9][0-9]{9}")
        if Pattern.match(mobile):
            mobileEncode = str(b64encode(('+91' + mobile).encode("ascii")), 'UTF-8')
            body = '{"number": "' + mobileEncode + '"}'
            jd = requests.post(url, headers=hdr, data=body).json()
            # xbmc.log(dumps(jd))
            if jd.get("resultCode") == "KO":
                xbmc.executebuiltin(
                    "Notification(%s, %s, %d, %s)"
                    % (_addonname, "Error Sending OTP", 3000, _icon)
                )
            else:
                OTP = xbmcgui.Dialog().numeric(0, "Enter OTP")
                url = 'https://auth-jiocinema.voot.com/userservice/apis/v4/loginotp/verify'
                body = {"deviceInfo":
                        {"consumptionDeviceName": "iPhone", "info": {"platform": {"name": "iPhone OS"}, "androidId": "3968183400", "type": "iOS"}},
                        "number": mobileEncode, "otp": OTP}
                body = dumps(body)
                jd = requests.post(url, headers=hdr, data=body).json()
                xbmc.log(dumps(jd))
                if jd.get("userId"):
                    _addon.setSetting("accesstoken", jd['authToken'])
                    _addon.setSetting("deviceid", jd['deviceId'])
                    _addon.setSetting("uniqueid", jd['userId'])

                    headers.update({"accesstoken": jd['authToken']})
                    headers.update({"deviceid": jd['deviceId']})
                    headers.update({"uniqueid": jd['userId']})
                    xbmc.executebuiltin(
                        "Notification(%s, %s, %d, %s)"
                        % (_addonname, "Login Successful", 3000, _icon)
                    )
                else:
                    xbmc.executebuiltin(
                        "Notification(%s, %s, %d, %s)"
                        % (_addonname, "Invalid/Expired OTP", 3000, _icon)
                    )
        else:
            xbmc.executebuiltin(
                "Notification(%s, %s, %d, %s)"
                % (_addonname, "Invalid Mobile Number", 3000, _icon)
            )
    return


if _settings("accesstoken"):
    headers.update({"accesstoken": _settings("accesstoken")})
    headers.update({"deviceid": _settings("deviceid")})
    headers.update({"uniqueid": _settings("uniqueid")})
else:
    guestToken()


"""
if _settings('EnableIP') == 'true':
    headers['X-Forwarded-For'] = _settings('ipaddress')

sortID = 'sortId=mostPopular'
if _settings('tvsort') == 'Name':
    sortID = 'sortId=a_to_z'

msort = 'sortId=mostPopular'
if _settings('msort') == 'Name':
    msort = 'sortId=a_to_z'
"""


def get_top():
    """
    Get the list of countries.
    :return: list
    """

    menu = []
    url = '%s/bff/menus' % (contentUrl)

    jd = requests.get(url, headers=headers).json()
    items = jd['bottomMenu'][0]['menuItems']
    # 
    for item in items:
        if item.get('viewType'):
            title = item.get('label')
            if title != 'More':
                icon = iconUrl + item.get('svgActiveIconUrl')
                path = item.get('relativeViewPath')
                menu.append((title, icon, path))
    menu.append(('Search', _icon, 'Search'))
    return menu


def get_langs():
    """
    Get the list of languages.
    :return: list
    """
    languages = ['Hindi', 'Marathi', 'Telugu',
                 'Kannada', 'Bengali', 'Gujarati', 'Tulu']

    langs = []
    for item in languages:
        url = '%s/content/generic/movies-by-language?language=include:%s&sort=title:asc,mostpopular:desc&responseType=common' % (
            apiUrl, item)

        jd = requests.get(url, headers=headers).json()
        tcount = jd['totalAsset']
        langs.append((item, tcount))

    return langs


def getlicense(id):
    token = ""
    if headers.get('ks'):
        hdr = {"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36",
               "content-type": "application/json",
               "authority": "rest-as.ott.kaltura.com",
               "accept-encoding": "gzip, deflate, br",
               "referer": "https://www.voot.com/",
               "origin": "https://www.voot.com"
               }
        url = "https://rest-as.ott.kaltura.com/v4_4/api_v3/service/multirequest"

        body = {"1": {"service": "asset", "action": "get", "id": id, "assetReferenceType": "media", "ks": headers['ks']}, "2": {"service": "asset", "action": "getPlaybackContext", "assetId": id, "assetType": "media", "contextDataParams": {
            "objectType": "KalturaPlaybackContextOptions", "context": "PLAYBACK"}, "ks": headers['ks']}, "apiVersion": "5.2.6", "ks": headers['ks'], "partnerId": 225}
        body = dumps(body)
        jd = requests.post(url, headers=hdr, data=body).json()
        for lictoken in jd['result'][1]['sources']:
            if lictoken.get('type') == 'DASH_LINEAR_APP' or lictoken.get('type') == 'DASHENC_PremiumHD':
                token = lictoken['drm'][1]['licenseURL']
    return token


def get_channels(id, offSet):
    """
    Get the list of channels.
    :return: list
    """
    channels = []
    finalpg = True
    # web_pdb.set_trace()
    url = '%s/%s?page=%s?&responseType=common&features=include:buttonsTray&premiumTrays=false&devicePlatformType=desktop' % (
        contentUrl, id, offSet)
    jd = requests.get(url, headers=headers).json()
    items = jd['trays']
    for item in items:
        title = item.get('title')
        apiUrl = item.get('apiUrl')
        channels.append((title, apiUrl, offSet))

    offSet = int(offSet)
    totals = int(jd['trayCount'])
    itemsLeft = totals - offSet * 4
    if itemsLeft > 0:
        offSet += 1
        url = '%s/%s?page=%s?&responseType=common&features=include:buttonsTray&premiumTrays=false&devicePlatformType=desktop' % (
            contentUrl, id, offSet)
        jd = requests.get(url, headers=headers).json()
        items = jd['trays']
        for item in items:
            title = item.get('title')
            apiUrl = item.get('apiUrl')
            channels.append((title, apiUrl, offSet))

    itemsLeft = totals - offSet * 4

    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 8.0))

    if not finalpg:
        title = 'Next Page.. (Currently in Page %s of %s)' % (int(math.ceil(offSet / 2.0)), pages)
        offSet += 1

        channels.append((title, apiUrl, offSet))
    return channels


def get_segments(channel, offSet):
    """
    Get the list of shows.
    :return: list
    """

    segments = []
    finalpg = True

    if channel in ('premium', 'sports', 'shows', 'movies'):
        url = '%s/view/%s?page=%s&responseType=common&features=include:buttonsTray' % (
            apiUrl, channel, offSet)
    else:
        url = '%s/view/channel/%s?page=%s&responseType=common&features=include:buttonsTray' % (
            apiUrl, channel, offSet)
    jd = requests.get(url, headers=headers).json()
    items = jd['trays']
    for item in items:
        title = item.get('title')
        if title:
            SegUrl = item.get('apiUrl')
            labels = {'title': title,
                      'mediatype': 'tvshow'}
            segments.append((title, SegUrl, labels))

    offSet = int(offSet)
    totals = int(jd['trayCount'])
    itemsLeft = totals - offSet * 4
    if itemsLeft > 0:
        offSet += 1
        if channel in ('premium', 'sports', 'shows', 'movies'):
            url = '%s/view/%s?page=%s&responseType=common&features=include:buttonsTray' % (
                apiUrl, channel, offSet)
        else:
            url = '%s/view/channel/%s?page=%s&responseType=common&features=include:buttonsTray' % (
                apiUrl, channel, offSet)
        jd = requests.get(url, headers=headers).json()
        items = jd['trays']
        for item in items:
            title = item.get('title')
            SegUrl = item.get('apiUrl')
            labels = {'title': title,
                      'mediatype': 'tvshow'}
            segments.append((title, SegUrl, labels))

        itemsLeft = totals - offSet * 4
    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 8.0))

    if not finalpg:
        title = 'Next Page.. (Currently in Page %s of %s)' % (
            offSet // 2, pages)
        offSet += 1

        segments.append((title, offSet, totals))

    return segments


def get_shows(SegUrl, offSet):
    """
    Get the list of shows.
    :return: list
    """

    shows = []
    finalpg = True

    url = '%s/%s&responseType=common&page=%s' % (contentUrl, SegUrl, offSet)
    jd = requests.get(url, headers=headers).json()
    
    items = jd['result']
    for item in items:
        title = item.get('fullTitle') if item.get(
            'fullTitle') else item.get('name')
        tcount = item.get('season') if item.get('season') else 1
        mediatype = item.get('mediaType')
        # web_pdb.set_trace()
        if mediatype == 'MOVIE':
            mtype = 'movie'
        else:
            mtype = 'tvshow'
        #item_id = item.get('jioMediaId')  # jioMediaId
        item_id = item.get('id')
        SBU = item.get('SBU')
        iconpath = 'https://v3img.voot.com/resizeMedium,w_810,h_1080/'
        icon = {'poster': iconpath + item['image3x4'].replace(' ', '%20'),
                'thumb': iconpath + item['image3x4'].replace(' ', '%20'),
                'icon': iconpath + item['image3x4'].replace(' ', '%20'),
                'fanart': iconpath + item['image3x4'].replace(' ', '%20')
                }
        labels = {'title': title,
                  'genre': item.get('genres'),
                  'season': item.get('season'),
                  'plot': item['fullSynopsis'],
                  'cast': item.get('contributors') if item.get('contributors') else [],
                  'mediatype': mtype,
                  'year': item['releaseYear']}
        shows.append((title, icon, mediatype, item_id,
                     tcount, labels, SBU))

    offSet = int(offSet)
    totals = int(jd['totalAsset'])
    itemsLeft = totals - offSet * 10

    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    if not finalpg:
        title = 'Next Page.. (Currently in Page %s of %s)' % (offSet, pages)
        offSet += 1

        labels = {}
        shows.append((title, _icon, mediatype,
                     offSet, tcount, labels, SBU))

    return shows


def get_season(show, offSet):
    """
    Get the list of episodes.
    :return: list
    """
    season = []
    # web_pdb.set_trace()
    finalpg = True
    url = '%s/content/generic/season-by-show?sort=season:desc&id=%s&page=%s&responseType=common' % (
        contentUrl, show, offSet)
    jd = requests.get(url, headers=headers).json()
    items = jd['result']
    for item in items:
        title = item.get('seasonName')
        item_id = item.get('seasonId')
        icon = {'poster': 'https://v3img.voot.com/' + item['image3x4'] if item.get('image3x4') else item['seo'].get('ogImage').replace(' ', '%20'),
                # 'https://v3img.voot.com/resizeMedium,w_175,h_100/'+item.get('image16x9'),
                'thumb': item['seo'].get('ogImage').replace(' ', '%20'),
                'icon': item['seo'].get('ogImage').replace(' ', '%20'),
                'fanart': item['seo'].get('ogImage').replace(' ', '%20')
                }
        # icon = item['seo'].get('ogImage').replace(' ','%20')
        sbu = item.get('SBU')
        labels = {'title': title,
                  'genre': item.get('genres'),
                  'plot': item['seo'].get('description'),
                  'cast': item.get('contributors'),
                  'tvshowtitle': item['fullTitle'],
                  'mediatype': 'tvshow',
                  'season': item.get('season')
                  }
        season.append((title, icon, sbu, item_id, labels))

    offSet = int(offSet)
    totals = jd['totalAsset'] if jd.get('totalAsset') else 1
    itemsLeft = totals - offSet * 10

    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    if not finalpg:
        title = 'Next Page.. (Currently in Page %s of %s)' % (offSet, pages)
        offSet += 1

        labels = {}
        season.append((title, _icon, offSet, show, labels))
    return season


def get_episodes(show, offSet):
    """
    Get the list of episodes.
    :return: list
    """
    episodes = []
    url = '%s/content/generic/series-wise-episode?sort=episode:desc&id=%s&&page=%s&responseType=common' % (
        contentUrl, show, offSet)

    jd = requests.get(url, headers=headers).json()
    totals = jd['totalAsset']
    finalpg = True
    items = jd['result']

    for item in items:
        title = item['seo'].get('title')
        eid = item.get('id')
        icon = {'poster': item['seo'].get('ogImage'),
                # 'https://v3img.voot.com/resizeMedium,w_175,h_100/'+item.get('image16x9'),
                'thumb': item['seo'].get('ogImage'),
                'icon': item['seo'].get('ogImage'),
                'fanart': item['seo'].get('ogImage')
                }
        labels = {'title': title,
                  'genre': item.get('genres'),
                  'cast': item.get('contributors'),
                  'plot': item.get('fullSynopsis'),
                  'duration': item['duration'],
                  'tvshowtitle': item['shortTitle'],
                  'mediatype': 'episode',
                  'episode': item.get('episode'),
                  'season': item.get('season'),
                  'aired': item.get('telecastDate')[:4] + '-' + item.get('telecastDate')[4:6] + '-' + item.get('telecastDate')[6:],
                  'year': item.get('releaseYear')
                  }
        # title = 'E%s %s'%(labels.get('episode'), title) if labels.get('episode') else title
        # title = 'S%02d%s'%(int(labels.get('season')), title) if labels.get('season') else title
        # td = item.get('telecastDate')
        # if td:
        #    labels.update({'aired': td[:4] + '-' + td[4:6] + '-' + td[6:]})
        premium = item.get('isPremium')
        episodes.append((title, icon, eid, labels, totals, premium))

    offSet = int(offSet)
    totals = int(totals)
    itemsLeft = totals - offSet * 10

    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    if not finalpg:
        title = 'Next Page.. (Currently in Page %s of %s)' % (offSet, pages)
        offSet += 1

        labels = {}
        episodes.append((title, _icon, offSet, labels, totals, premium))

    return episodes


def get_movies(lang, offSet, totals):
    """
    Get the list of movies.
    :return: list
    title:asc,
    """
    movies = []
    totals = int(totals)
    offSet = int(offSet)
    finalpg = True
    itemsLeft = totals - (offSet) * 10
    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    url = '%s/content/generic/movies-by-language?language=include:%s&sort=mostpopular:desc&&page=%s&responseType=common' % (
        contentUrl, lang, offSet)
    jd = requests.get(url, headers=headers).json()
    items = jd['result']

    for item in items:
        title = item.get('name')
        mid = item.get('id')
        icon = item['seo'].get('ogImage')
        premium = item.get('isPremium')
        labels = {'title': title,
                  'genre': item.get('genres'),
                  'plot': item.get('fullSynopsis'),
                  'cast': item.get('contributors'),
                  # int(item.get('duration', '0'))/60,
                  'duration': item.get('duration'),
                  'mediatype': 'movie',
                  'mpaa': item.get('age'),
                  'aired': item.get('telecastDate')[:4] + '-' + item.get('telecastDate')[4:6] + '-' + item.get('telecastDate')[6:],
                  'year': item.get('releaseYear')
                  }
        movies.append((title, icon, mid, labels, premium))

    if not finalpg:
        title = 'Next Page.. (Currently in Page %s of %s)' % (offSet, pages)
        offSet += 1
        labels = {}
        movies.append((title, _icon, offSet, labels, premium))

    return movies


def get_user_input():
    kb = xbmc.Keyboard(
        '', 'Search for Movies/TV Shows/Trailers/Videos in all languages')
    kb.doModal()  # Onscreen keyboard appears
    if not kb.isConfirmed():
        return

    # User input
    return kb.getText()


def get_search(Query):
    """
    Get the list of shows.
    :return: list
    """
    search = []
    hdr = headers
    hdr.update({'x-algolia-api-key': 'e426ce68fbce6f9262f6b9c3058c4ea9'})
    hdr.update({'x-algolia-application-id': 'JN1RDQRFN5'})

    url = 'https://algolia.voot.com/1/indexes/*/queries?x-algolia-agent=Algolia%20for%20JavaScript%20(4.16.0)%3B%20Browser'
    body = {"requests":[{"indexName": "prod_jiovoot_elastic", "query": Query, "params": ""},
                        {"indexName": "prod_jiovoot_elastic", "query": Query, "params": "filters=genres:Sports"},
                        {"indexName": "prod_jiovoot_elastic", "query": Query, "params": "filters=mediaType:MOVIE"},
                        {"indexName": "prod_jiovoot_elastic", "query": Query, "params": "filters=mediaType:SHOW"}]}
    body = dumps(body)
    # web_pdb.set_trace()
    jd = requests.post(url, headers=headers, data=body).json()
    items = jd['results'][0]['hits']
    for item in items:
        title = item.get('fullTitle') if item.get(
            'fullTitle') else item.get('name')
        eid = item.get('id')
        showtype = item.get('mediaType')
        icon = {'poster': item['seo'].get('ogImage'),
                # 'https://v3img.voot.com/resizeMedium,w_175,h_100/'+item.get('image16x9'),
                'thumb': item['seo'].get('ogImage'),
                'icon': item['seo'].get('ogImage'),
                'fanart': item['seo'].get('ogImage')
                }
        labels = {'title': title,
                  'genre': item.get('genres'),
                  'cast': item.get('contributors'),
                  'plot': item.get('fullSynopsis'),
                  'duration': item['duration'],
                  'tvshowtitle': item['shortTitle'],
                  'mediatype': 'episode',
                  'episode': item.get('episode'),
                  'season': item.get('season'),
                  'aired': item.get('telecastDate')[:4] + '-' + item.get('telecastDate')[4:6] + '-' + item.get('telecastDate')[6:],
                  'year': item.get('releaseYear')
                  }

        premium = item.get('isPremium')
        search.append((title, icon, eid, labels, showtype, premium))
    """
    offSet = int(offSet)
    totals = int(totals)
    itemsLeft = totals - offSet * 10

    if itemsLeft > 0:
        finalpg = False
        pages = int(math.ceil(totals/10.0))

    if not finalpg:
        title = 'Next Page.. (Currently in Page %s of %s)' % (offSet,pages)
        offSet += 1

        labels = {}
        search.append((title,_icon,offSet,labels,premium))
    """
    return search


def list_search():
    """
    Create the list of channels in the Kodi interface.
    """

    query = get_user_input()
    if not query:
        return []

    # shows = cache.cacheFunction(get_search,query)
    search = get_search(query)
    listing = []
    #
    for title, icon, item_id, labels, mediatype, premium in search:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)

        if 'Next Page' not in title:
            if mediatype in ('MOVIE', 'CAC', 'EPISODE'):
                list_item.setProperty('IsPlayable', 'true')
                url = '{0}?action=play&video={1}&vidtype=VIDEO'.format(_url, item_id)
                is_folder = False
            elif mediatype in ('LIVECHANNEL'):
                list_item.setProperty('IsPlayable', 'true')
                url = '{0}?action=play&video={1}&vidtype=VIDEO'.format(
                    _url, item_id)
                is_folder = False
            else:
                url = '{0}?action=list_season&offSet=1&show={1}'.format(
                    _url, item_id)
                is_folder = True
        else:
            url = '{0}?action=list_show&show={1}&offSet=1&totals=1&icon={2}'.format(
                _url, item_id, icon)
            is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'tvshows')
    xbmcplugin.endOfDirectory(_handle)


def list_top():
    """
    Create the list of countries in the Kodi interface.
    """
    items = get_top()

    listing = []
    for title, icon, path in items:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setInfo('video', {'title': title, 'genre': title})
        list_item.setArt({'icon': _icon,
                          'poster': _icon,
                          'thumb': _icon,
                          'fanart': _icon})
        if title == 'Search':
            url = '{0}?action=Search'.format(_url)
        else:
            url = '{0}?action=Channels&id={1}&offSet=1'.format(_url, path)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)


def list_channels(id, offSet):
    """
    Create the list of countries in the Kodi interface.
    """

    channels = get_channels(id, offSet)
    listing = []
    for title, apiUrl, offSet in channels:
        list_item = xbmcgui.ListItem(
            label='[COLOR yellow]%s[/COLOR]' % (title))
        list_item.setArt({'poster': _icon,
                          'icon': _icon,
                          'thumb': _icon,
                          'fanart': _fanart})
        list_item.setInfo('video', {'title': title})

        if 'Next Page' in title:
            url = '{0}?action=Channels&id={1}&offSet={2}'.format(
                _url, id, offSet)
            is_folder = True
        else:
            url = '{0}?action=list_shows&SegUrl={1}&offSet=1'.format(
                _url, apiUrl)
            is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    # xbmcplugin.setContent(_handle, 'videos')
    xbmcplugin.endOfDirectory(_handle)


def list_segments(channel, offSet):
    """
    Create the list of channels in the Kodi interface.
    """
    segments = cache.cacheFunction(get_segments, channel, offSet)
    listing = []
    for title, SegUrl, labels in segments:
        if 'Next Page' not in title:
            list_item = xbmcgui.ListItem(
                label='[COLOR yellow]%s  [COLOR cyan][/COLOR]' % (title))
            url = '{0}?action=list_channel&SegUrl={1}&offSet=1'.format(
                _url, SegUrl)
        else:
            list_item = xbmcgui.ListItem(
                label='[COLOR yellow]%s[/COLOR]' % (title))
            url = '{0}?action=list_segment&channel={1}&offSet={2}'.format(
                _url, channel, SegUrl)

        list_item.setInfo('video', labels)

        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    # xbmcplugin.setContent(_handle, 'tvshows')
    xbmcplugin.endOfDirectory(_handle)


def list_shows(SegUrl, offSet):
    """
    Create the list of channels in the Kodi interface.
    """
    shows = get_shows(SegUrl, offSet)
    listing = []

    for title, icon, mediatype, item_id, tcount, labels, SBU in shows:
        if 'Next Page' not in title:
            list_item = xbmcgui.ListItem(
                label='[COLOR yellow]%s  [COLOR cyan][/COLOR]' % (title))
            if mediatype in ('MOVIE', 'CAC', 'EPISODE'):
                list_item.setProperty('IsPlayable', 'true')
                url = '{0}?action=play&video={1}&vidtype=VIDEO'.format(_url, item_id)
                is_folder = False
            elif mediatype in ('LIVECHANNEL'):
                list_item.setProperty('IsPlayable', 'true')
                url = '{0}?action=play&video={1}&vidtype=VIDEO'.format(
                    _url, item_id)
                is_folder = False
            else:
                #if SBU == 'COH':
                #    url = '{0}?action=Channels&id={1}&offSet=1'.format(
                #        _url, item_id)
                #else:
                url = '{0}?action=list_season&offSet=1&show={1}'.format(
                    _url, item_id)
                is_folder = True
        else:
            list_item = xbmcgui.ListItem(
                label='[COLOR yellow]%s[/COLOR]' % (title))
            url = '{0}?action=list_shows&SegUrl={1}&offSet={2}'.format(
                _url, SegUrl, item_id)
            is_folder = True

        list_item.setArt(icon)

        list_item.setInfo('video', labels)
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))

    if mediatype in ('MOVIE', 'CAC', 'EPISODE', 'LIVECHANNEL'):
        xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)


def list_season(show, offSet):
    """
    Create the list of episodes in the Kodi interface.
    """
    season = get_season(show, offSet)
    listing = []
    for title, icon, sid, item_id, labels in season:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)
        if 'Next Page' not in title:
            url = '{0}?action=list_show&show={1}&offSet={2}&icon={3}'.format(
                _url, item_id, offSet, icon)
        else:
            url = '{0}?action=list_season&offSet={1}&show={2}'.format(
                _url, sid, item_id)

        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    # xbmcplugin.setContent(_handle, 'tvshows')
    xbmcplugin.endOfDirectory(_handle)


def list_episodes(show, offSet, sicon):
    """
    Create the list of episodes in the Kodi interface.
    """
    episodes = cache.cacheFunction(get_episodes, show, offSet)
    listing = []

    for title, icon, eid, labels, totals, premium in episodes:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)
        is_folder = False
        if 'Next Page' not in title:
            list_item.setProperty('IsPlayable', 'true')
            if premium:
                url = '{0}?action=play&video={1}&vidtype=PREMIUM'.format(
                    _url, eid)
            else:
                url = '{0}?action=play&video={1}&vidtype=VIDEO'.format(
                    _url, eid)
            is_folder = False
        else:
            url = '{0}?action=list_show&show={1}&offSet={2}&totals={3}&icon={4}'.format(
                _url, show, eid, totals, sicon)
            is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'episodes')
    xbmcplugin.endOfDirectory(_handle)


def list_langs():
    """
    Create the list of countries in the Kodi interface.
    """
    langs = cache.cacheFunction(get_langs)
    listing = []
    for lang, tcount in langs:
        list_item = xbmcgui.ListItem(
            label='[COLOR yellow]%s  [COLOR cyan](%s movies)[/COLOR]' % (lang, tcount))
        list_item.setInfo('video', {'title': lang, 'genre': lang})
        list_item.setArt({'poster': _icon,
                          'icon': _icon,
                          'thumb': _icon,
                          'fanart': _fanart})
        url = '{0}?action=list_movies&lang={1}&offSet=1&totals={2}'.format(
            _url, lang, tcount)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)


def list_movies(lang, offSet, totals):
    """
    Create the list of episodes in the Kodi interface.
    """
    movies = cache.cacheFunction(get_movies, lang, offSet, totals)
    listing = []
    for title, icon, mid, labels, premium in movies:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({'poster': icon,
                          'icon': icon,
                          'thumb': icon,
                          'fanart': icon})
        list_item.setInfo('video', labels)
        is_folder = False
        if 'Next Page' not in title:
            list_item.setProperty('IsPlayable', 'true')
            if premium:
                url = '{0}?action=play&video={1}&vidtype=PREMIUM'.format(
                    _url, mid)
            else:
                url = '{0}?action=play&video={1}&vidtype=VIDEO'.format(
                    _url, mid)
        else:
            url = '{0}?action=list_movies&lang={1}&offSet={2}&totals={3}'.format(
                _url, lang, mid, totals)
            is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle, succeeded=True,
                              updateListing=True, cacheToDisc=True)


def play(urlid, vidtype):
    """
    Play a video by the provided path.

    """
    #
    # web_pdb.set_trace()
    stream_url = ''
    # max_bandwidth = '10000'
    # vidtype='VIDEO'
    headers.update({'x-playbackid': str(uuid.uuid4())})
    headers.update({'uniqueid': '8d006715-bcb9-43db-ae37-592044e38447'})
    headers.update({'content-type': 'application/json'})
    headers.update({'versioncode': '407'})
    headers.update({'x-feature-code': 'ytvjywxwkn'})
    headers.update({'x-platform': 'androidweb'})
    headers.update({'x-platform-token': 'web'})
    # web_pdb.set_trace()
    if vidtype == 'LIVE':
        url = contentUrl + "/view/live-channel//%s" % (urlid)
        jd = requests.get(url, headers=headers).json()
        stream_url = jd['data']['playbackUrls'][0].get('url')
        if stream_url:
            videoid = jd.get('videoId') if jd.get('videoId') else urlid
            lic_url = '%s?videoid=%s&vootid=%s&isVoot=true&voottoken=%s' % (
                jd['mpdKey'], videoid, urlid, headers['voottoken'])
            license_key = '%s|%s&Content-Type=application/octet-stream|R{SSM}|' % (
                lic_url, urllib_parse.urlencode(hdr))
    else:
        url = apiUrl + 'playbackjv/v3/%s' % (urlid)
        body = {"4k": False, "ageGroup": "18+", "appVersion": "3.4.0", "bitrateProfile": "xhdpi", "capability": {"drmCapability": {"aesSupport": "yes", "fairPlayDrmSupport": "yes", "playreadyDrmSupport": "none", "widevineDRMSupport": "yes"}, "frameRateCapability": [{"frameRateSupport": "30fps", "videoQuality": "1440p"}]}, "continueWatchingRequired": False, "dolby": False, "downloadRequest": False, "hevc": False, "kidsSafe": False, "manufacturer": "Windows", "model": "Windows", "multiAudioRequired": True, "osVersion": "10", "parentalPinValid": True, "x-apisignatures": "o668nxgzwff"}
        body = dumps(body)


        # web_pdb.set_trace()
        jd = requests.post(url, headers=headers, data=body).json()
        if jd.get('data'):
            stream_url = jd['data']['playbackUrls'][0].get('url')
            lic_url = jd['data']['playbackUrls'][0].get('licenseurl')
            license_key = '%s|%s|R{SSM}|' % (lic_url, urllib_parse.urlencode(headers))

    if not stream_url:
        msg = "Need Premium subsription"
        xbmcgui.Dialog().notification(_addonname, msg, _icon, 3000, False)
    else:
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setPath(stream_url)

        if six.PY3:
            play_item.setProperty('inputstream', 'inputstream.adaptive')
        else:
            play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')

        if (stream_url.find('mpd') != -1):
            play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            play_item.setMimeType('application/dash+xml')
        else:
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            play_item.setMimeType('application/vnd.apple.mpegurl')

        if license_key != "":
            play_item.setProperty(
                'inputstream.adaptive.license_type', 'com.widevine.alpha')
            play_item.setProperty(
                'inputstream.adaptive.license_key', license_key)
            play_item.setProperty(
                "inputstream.adaptive.stream_headers", urllib_parse.urlencode(headers))
            # xbmcgui.Dialog().notification(_addonname, 'Playing DRM.......', _icon, 3000, False)
            #if max_bandwidth:
            #    play_item.setProperty(
            #        'inputstream.adaptive.max_bandwidth', max_bandwidth)

        play_item.setContentLookup(False)

        # Pass the item to the Kodi player.
        xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)

