

import sys

from kodi_six import xbmc, xbmcaddon, xbmcplugin, xbmcgui, xbmcvfs
from six.moves import urllib_parse, urllib_request ,BaseHTTPServer, socketserver
import six
import re 
import requests
import time
import web_pdb
#import SocketServer
import socket
import threading
import os
from datetime import datetime
import uuid
try:
    import StorageServer
except:
    import storageserverdummy as StorageServer

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

_addon = xbmcaddon.Addon()
_addonname = _addon.getAddonInfo('name')
_version = _addon.getAddonInfo('version')
_addonID = _addon.getAddonInfo('id')
_icon = _addon.getAddonInfo('icon')
_fanart = _addon.getAddonInfo('fanart')
_settings = _addon.getSetting

cache = StorageServer.StorageServer('sonyliv', _settings('timeout'))

headers= {
    "Content-Type": "application/json",
    "x-via-device": "true",
    "app_version": "3.2.30"
    }

def get_token():
    url='https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/ALL/GETTOKEN'
    data = requests.get(url, headers=headers).json()
    return data['resultObj']

if 'security_token' not in headers:
    headers["security_token"] = get_token()

def clear_cache():
    """
    Clear the cache database.
    """
    msg = 'Cached Data has been cleared'
    cache.table_name = 'sonyliv'
    cache.cacheDelete('%get%')
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(_addonname, msg, 3000, _icon))


apiUrl = 'https://www.sonyliv.com/api/v4/vod/search'


def get_laurl(thdr,tid):
    """
    Get the policy key.
    :return: string
    """
    thdr.update({'assetId': tid})
    thdr.update({'actionType': 'play'})
    thdr.update({'browser': 'Chrome'})
    thdr.update({'os': 'os'})
    thdr.update({'platform': 'web'})

    #url = 'https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN/CONTENT/GETLAURL?assetId=%s'%tid
    url = 'https://apiv2.sonyliv.com/AGL/1.5/A/ENG/WEB/IN/DETAIL/GETLAURL?assetId=%s'%tid
    jdata = requests.get(url, headers=thdr).json()
    #web_pdb.set_trace()
    laurl=jdata['resultObj'].get('laURL')
    return laurl

def get_Profile():

    thdr=headers
    thdr.update({'device_id': 'c898b0bb45fd4dd389b20bdc1706b78b-1607099808124'})
    thdr.update({'x-via-device': 'true'})
    thdr.update({'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIyMDEyMTYxNTM4MTYwNjQ5NTI4IiwidG9rZW4iOiIwT0tNLW5LQkstMjh5ci1xZDdpLU9DTkstSjBERi1CVyIsImV4cGlyYXRpb25Nb21lbnQiOiIyMDIyLTAyLTA2VDA2OjM4OjI5Ljc3MVoiLCJpc1Byb2ZpbGVDb21wbGV0ZSI6ZmFsc2UsImNoYW5uZWxQYXJ0bmVySUQiOiJNU01JTkQiLCJmaXJzdE5hbWUiOiIiLCJsYXN0TmFtZSI6IiIsIm1haWwiOiJ2aWthc3NtNzNAZ21haWwuY29tIiwic2Vzc2lvbkNyZWF0aW9uVGltZSI6IjIwMjAtMTItMTZUMTU6Mzg6MjkuODI0WiIsIm1vYmlsZU51bWJlciI6IiIsImRhdGVPZkJpcnRoIjoiIiwiZ2VuZGVyIjoiIiwicHJvZmlsZVBpYyI6IiIsInNvY2lhbFByb2ZpbGVQaWMiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vLU1PcG9TSElFQjlFL0FBQUFBQUFBQUFJL0FBQUFBQUFBQUFBL0FNWnV1Y25wcV9MQWdLcHNzTmZvNTY0V0NjTnRpN2FyUncvczk2LWMvcGhvdG8uanBnIiwic29jaWFsTG9naW5JRCI6IkdVXzExMzIxMTg1Nzk4MTc1OTk2MDA4NyIsInNvY2lhbExvZ2luVHlwZSI6Ikdvb2dsZSIsImlzRW1haWxWZXJpZmllZCI6dHJ1ZSwiaXNNb2JpbGVWZXJpZmllZCI6ZmFsc2UsImVtYWlsIjoidmlrYXNzbTczQGdtYWlsLmNvbSIsImlzQ3VzdG9tZXJFbGlnaWJsZUZvckZyZWVUcmlhbCI6ZmFsc2UsImNvbnRhY3RJRCI6IjE2MTQxOTUxMiIsImlhdCI6MTYwODEzMzEwOSwiZXhwIjoxNjQ0MTI5NDQ5fQ.xl3L4p8PqLPvosPTh1NyubPRAnAjZJ_gj2Y2Oae3Yvs'})
    url = 'https://apiv2.sonyliv.com/AGL/1.6/A/ENG/WEB/IN/GETPROFILE?channelPartnerID=MSMIND'
    jdata = requests.get(url, headers=thdr).json()
    #web_pdb.set_trace()
    laurl=jdata['resultObj'].get('accessToken')
    return laurl

def get_actor(cast):
    parts = cast.split('|')
    CastlistCastlist = ''
    for part in parts:
        if show not in part.lower():
            r = re.search(r'\d{4}',part)
            if not r:
                etitle += part + ' '
    if len(etitle) < 4:
        CastlistCastlist = cast
    return Castlist

def go_page(sid,total):
    page=xbmcgui.Dialog().numeric(0,'Page episodeNumber')
    #web_pdb.set_trace()
    if page:
        page=int(page)
        pages=int(total)/10
        pages=pages+1 if int(total)%10 >0 else pages
        page=pages-1 if page>pages else page-1

        list_episodes(sid,'page',page,total)

    return 


def get_bands():
    """
    Get the show bands.
    :return: json
    """
    url = 'https://www.sonyliv.com/api/configuration/asset_band_details'
    jdata = requests.get(url, headers=headers).json()
    return jdata


def get_srt(vttfile):
    content = requests.get(vttfile,headers=headers).content
    replacement = re.sub(r'([\d]+)\.([\d]+)', r'\1,\2', content)
    replacement = re.sub(r'WEBVTT\n\n', '', replacement)
    replacement = re.sub(r'^\d+\n', '', replacement)
    replacement = re.sub(r'\n\d+\n', '\n', replacement)
    replacement = six.StringIO(replacement)
    idx = 1
    content = ''
    for line in replacement:
        if '-->' in line:
            if len(line.split(' --> ')[0]) < 12:
                line = re.sub(r'([\d]+):([\d]+),([\d]+)', r'00:\1:\2,\3', line)
            content += '%s\n%s'%(idx,line) 
            idx += 1
        else:
            content += line
    f = xbmcvfs.File('special://temp/TemporarySubs.en.srt','w')
    result = f.write(content)
    f.close()
    return 'special://temp/TemporarySubs.en.srt'


def get_top():
    """
    Get the list of countries.
    :return: list
    """
    MAINLIST = ['Channels', 'Movies', 'Clear Cache']
    return MAINLIST

def get_showdata(show,title):
    """
    Get the list of channels.
    :return: list
    """
    jd = cache.cacheFunction(get_bands)
    bands = jd['asset_band_details'][1]['bands']
    #xbmc.log('@@@@Show title = %s'%title,xbmc.LOGNOTICE)
    sdata = 'exact=true&all=type:Episodes&all=showname:%s'%show
    stype = 'search'
    id = 'Episodes'
    sort = 'START_DATE:DESC'
    for band in bands:
        if band['title'].lower() == title:
            sdata = band['data']
            stype = band['type']
            id = band['id']
            sort = band['sort']
            break
    
    return (sdata,stype,id,sort)


def get_channels():
    """
    Get the list of channels.
    :return: list
    """
    channels = []

    url = 'https://apiv2.sonyliv.com/AGL/1.5/A/ENG/WEB/IN/PAGE/2240?from=01&to=24'
    jd = requests.get(url,headers=headers).json()
    cnav = jd['resultObj']['containers']
    for cn in cnav:
        title = cn['metadata'].get('label')
        cid = cn['metadata'].get('id')
        #xbmc.log('AJAY: %s\n\n' % cn)
        channels.append((title,cid))

    return channels

def get_shows(cid):
    """
    Get the list of shows.
    :return: list
    """
    shows = []
    nextpg = True
    page = 0  

    url='https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN/PAGE/%s?from=0&to=9'%(cid)
    jd = requests.get(url,headers=headers).json()
    items = jd['resultObj']['containers'][0]['assets']['containers']
    #
    for item in items:
        title = item['metadata'].get('title')

        labels = {'title': title,
                  'genre': item['metadata'].get('genres'),
                  'plot': item['metadata'].get('longDescription'),
                  'mediatype': 'tvshow'
                 }


        fanart = item['metadata']['emfAttributes'].get('masthead_background')
        if not fanart:
            fanart = item['metadata']['emfAttributes'].get('masthead_background_mobile')

        icon = item['metadata']['emfAttributes'].get('masthead_foreground')
        poster = item['metadata']['emfAttributes'].get('portrait_thumb')
        thumb = item['metadata']['emfAttributes'].get('masthead_logo')

        icon = {'poster': poster,
               'icon': icon,
               'thumb': thumb,
               'fanart': fanart}
        try:
            labels['aired'] = datetime.fromtimestamp(item['metadata'].get('contractStartDate')/1000.0).strftime('%Y-%m-%d')
        except:
            pass

        sid=item['id']
        stype=item['metadata'].get('objectSubtype')
        shows.append((title,icon,sid,labels,stype))
    return shows

def get_season(sid):
    """
    Get the list of episodes.
    :return: list
    """
    season = []

    url='https://apiv2.sonyliv.com/AGL/1.5/A/ENG/WEB/IN/DETAIL/'+sid

    jd = requests.get(url,headers=headers).json()
    items = jd['resultObj']['containers'][0]['containers']
    
    for item in items:
        #web_pdb.set_trace()
        subtype=item['metadata'].get('contentSubtype')

        if item.get('episodeCount'):
            tcount=item.get('episodeCount')
        else:
            tcount=100
        if subtype=='EPISODE':
            stitle = '%s Episode %s'%(item['metadata'].get('title'),item['metadata'].get('episodeNumber'))
            labels = {'title': stitle,
                      'duration': item['metadata'].get('duration'),
                      'episode': item['metadata'].get('episodeNumber'),
                      'year': item['metadata'].get('year'),
                      'tvshowtitle': stitle,
                      'mediatype': 'episode'
                     }
        else:
            stitle = item['metadata'].get('title')
            labels = {'title': stitle,
                      'mediatype': 'season'
                     }

        fanart = item['metadata']['emfAttributes'].get('tv_background_image')
        poster = item['metadata']['emfAttributes'].get('poster')
        icon = item['metadata']['emfAttributes'].get('landscape_thumb')
        thumb = item['metadata']['emfAttributes'].get('thumbnail')

        icon = {'poster': poster,
               'icon': icon,
               'thumb': thumb,
               'fanart': fanart}


        sid=item['id']
        labels['genre'] = item['metadata'].get('genres')
        labels['plot'] = item['metadata'].get('longDescription')
        labels['aired'] = datetime.fromtimestamp(item['metadata'].get('originalAirDate')/1000.0).strftime('%Y-%m-%d') if item['metadata'].get('originalAirDate') else None
        season.append((stitle,icon,sid,subtype,labels,tcount))

    return season

def get_episodes(sid,title,page,total):
    """
    Get the list of episodes.
    :return: list
    """
    episodes = []
    page = int(page)
    fpage=int(page)*10
    tpage=(int(page)+1)*10-1

    url='https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN/CONTENT/DETAIL/BUNDLE/%s?from=%s&to=%s'%(sid,fpage,tpage)
    jd = requests.get(url,headers=headers).json()
    items = jd['resultObj']['containers'][0]['containers']
    for item in items:
        etitle = '{} - Episodes {}'.format(item['metadata'].get('episodeTitle').encode("utf8"),item['metadata'].get('episodeNumber'))
        eid=item.get('id')
        extid=item['metadata'].get('externalId')
        plot=item['metadata'].get('longDescription')
        if item['metadata']['emfAttributes'].get('cast_and_crew') is not None:
            plot=plot+'\n\n'+item['metadata']['emfAttributes'].get('cast_and_crew')
        labels = {'title': etitle,
                  'genre': item['metadata'].get('genres'),
                  #'cast':item['metadata'].get('actors'),
                  'plot': plot,
                  'duration': item['metadata'].get('duration'),
                  'episode': item['metadata'].get('episodeNumber'),
                  'tvshowtitle': etitle,
                  'year':item['metadata'].get('year'),
                  'aired':datetime.fromtimestamp(item['metadata'].get('originalAirDate')/1000.0).strftime('%Y-%m-%d'),
                  'mediatype': 'episode'
                 }
        fanart = item['metadata']['emfAttributes'].get('tv_background_image')
        poster = item['metadata']['emfAttributes'].get('poster')
        icon = item['metadata']['emfAttributes'].get('landscape_thumb')
        thumb = item['metadata']['emfAttributes'].get('thumbnail')

        icon = {'poster': poster,
               'icon': icon,
               'thumb': thumb,
               'fanart': fanart}

        episodes.append((etitle,icon,eid,extid,labels,total))
    total=items[0].get('episodeCount') if items[0].get('episodeCount') is not None else total
    page += 1
    BalCount=int(total)-page*10
    if BalCount > 0:
        pages=int(total)/10
        pages=pages+1 if int(total)%10 >0 else pages
        etitle = 'Next Page... (Page %s of %s)'%(page,pages)
        labels = {}
        icon = {'poster': _icon,
               'icon': _icon,
               'thumb': _icon,
               'fanart': fanart}
        episodes.append((etitle,icon,page,extid,labels,total))
        etitle = 'Go Page...'
        labels = {}
        icon = {'poster': _icon,
               'icon': _icon,
               'thumb': _icon,
               'fanart': fanart}
        episodes.append((etitle,icon,page,extid,labels,total))
    return episodes

def get_moviegenres():
    """
    Get the list of channels.
    :return: list
    """
    channels = []
    #url = 'https://apiv2.sonyliv.com/AGL/1.5/A/ENG/WEB/IN/PAGE/2245?from=01&to=14'
    url = 'https://apiv2.sonyliv.com/AGL/1.5/A/ENG/WEB/IN/PAGE/399?from=01&to=38'
    jd = requests.get(url,headers=headers).json()
    cnav = jd['resultObj']['containers']
    """
    sys.stdout = open(r"D:/logs.txt", 'w')
    print(cnav)
    sys.stdout.close()
    """
    for cn in cnav:
        title = cn['metadata'].get('label')
        cid = cn['metadata'].get('id')
        uri=cn['actions'][0].get('uri')
        total= cn['assets'].get('total') if cn.get('assets') else 100
        channels.append((title,cid,uri,total))

    return channels

def get_movies(gid,page,uri,total):
    """
    Get the list of movies.
    :return: list
    """
    movies = []
    page = int(page)
    fpage=int(page)*10
    tpage=(int(page)+1)*10-1

    if (uri.find('SEARCH') == -1):
        url='https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN/PAGE/%s?from=0&to=9'%(gid)
        NoNext=True
        jd = requests.get(url,headers=headers).json()
        items = jd['resultObj']['containers'][0]['assets']['containers']
    else:
        url='https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN%s&from=%s&to=%s'%(uri,fpage,tpage)
        NoNext=False
        jd = requests.get(url,headers=headers).json()
        items = jd['resultObj']['containers']
    
    for item in items:
        mtitle = item['metadata'].get('title').encode("utf8")
        mid=item.get('id')
        mextid=item['metadata'].get('externalId')
        subtype=item['metadata'].get('contentSubtype')
        plot=item['metadata'].get('longDescription')
        #web_pdb.set_trace()

        if item['metadata']['emfAttributes'].get('cast_and_crew') is not None:
            plot=plot+'\n\n'+item['metadata']['emfAttributes'].get('cast_and_crew')

        labels = {'title': mtitle,
                  'genre': item['metadata'].get('genres'),
                  #'cast':item['metadata']['emfAttributes'].get('cast_and_crew'),
                  'plot': plot,
                  'duration': item['metadata'].get('duration'),
                  'year':item['metadata'].get('year'),
                  'mediatype': 'movie'
                 } 
        fanart = item['metadata']['emfAttributes'].get('tv_background_image')
        poster = item['metadata']['emfAttributes'].get('portrait_thumb')
        icon = item['metadata']['emfAttributes'].get('landscape_thumb')
        thumb = item['metadata']['emfAttributes'].get('thumbnail')

        icon = {'poster': poster,
               'icon': icon,
               'thumb': thumb,
               'fanart': fanart}
        try:
            labels['premiered'] = datetime.fromtimestamp(item['metadata'].get('originalAirDate')/1000.0).strftime('%Y-%m-%d')
        except:
            pass
        movies.append((mtitle,icon,mid,mextid,subtype,labels,total))
    if NoNext==False:
        page += 1
        BalCount=int(total)-page*10
        if BalCount > 0:
            mtitle = 'Next Page... (Page %s of %s)'%(page,(int(total)/10)+1)
            labels = {}
            icon = {'poster': _icon,
                   'icon': _icon,
                   'thumb': _icon,
                   'fanart': fanart}
            movies.append((mtitle,icon,page,mextid,subtype,labels,total))

    return movies

def list_top():
    """
    Create the list of countries in the Kodi interface.
    """
    items = get_top()
    listing = []
    for item in items:
        list_item = xbmcgui.ListItem(label=item)
        list_item.setInfo('video', {'title': item, 'genre': item})
        list_item.setProperty('IsPlayable', 'false')
        list_item.setArt({'poster': _icon,
                          'icon': _icon,
                          'thumb': _icon,
                          'fanart': _fanart})
        url = '{0}?action=list_item&item={1}'.format(_url, item)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    #xbmcplugin.setContent(_handle, 'addons')
    xbmcplugin.endOfDirectory(_handle)


def list_moviegenres():
    """
    Create the list of countries in the Kodi interface.
    """
    langs = cache.cacheFunction(get_moviegenres)
    listing = []
    for title,mgid,uri,tcount in langs:
        #web_pdb.set_trace()
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]'%(title))
        list_item.setInfo('video', {'title': title})
        list_item.setProperty('IsPlayable', 'false')
        list_item.setArt({'poster': _icon,
                          'icon': _icon,
                          'thumb': _icon,
                          'fanart': _fanart})
        url = '{0}?action=list_movies&mgid={1}&page=0&url={2}&total={3}'.format(_url, mgid,urllib_parse.quote_plus(uri),tcount)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    #xbmcplugin.setContent(_handle, 'addons')
    xbmcplugin.endOfDirectory(_handle)

def list_movies(gid,page,uri,total):
    """
    Create the list of episodes in the Kodi interface.
    """
    movies = cache.cacheFunction(get_movies,gid,page,uri,total)
    listing = []
    #web_pdb.set_trace()
    for title,icon,mid,extid,stype,labels,tcount in movies:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)
        if 'Next Page' in title:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_movies&mgid={1}&page={2}&url={3}&total={4}'.format(_url,gid,mid,urllib_parse.quote_plus(uri),tcount)
            is_folder = True
        else:
            list_item.setProperty('IsPlayable', 'true')
            list_item.addStreamInfo('video', {'codec': 'h264'})
            #list_item.addStreamInfo('audio', { 'codec': 'mp4', 'channels': 2 })
            if stype =='LIVE_CHANNEL':
                url = '{0}?action=Play&video={1}&ltype={2}'.format(_url, mid,'Live')
            else:
                url = '{0}?action=Play&video={1}&ltype={2}'.format(_url, mid,'Stream')

            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)

def list_channels():
    """
    Create the list of countries in the Kodi interface.
    """
    channels = cache.cacheFunction(get_channels)
    listing = []
    for title,cid in channels:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]'%title)
        list_item.setProperty('IsPlayable', 'false')
        list_item.setArt({'poster': _icon,
                          'icon': _icon,
                          'thumb': _icon,
                          'fanart': _fanart})
        list_item.setInfo('video', {'title': title})
        url = '{0}?action=list_shows&cid={1}'.format(_url, cid)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    #xbmcplugin.setContent(_handle, 'addons')
    xbmcplugin.endOfDirectory(_handle)

def list_shows(cid):
    """
    Create the list of channels in the Kodi interface.
    """
    shows = cache.cacheFunction(get_shows,cid)
    listing = []
    #web_pdb.set_trace()
    for title,icon,sid,labels,stype in shows:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]'%title)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)
        #
        if stype in ['CLIP','EPISODE']:
            list_item.setProperty('IsPlayable', 'true')
            url = '{0}?action=Play&video={1}&ltype={2}'.format(_url, sid,'Stream')
            is_folder = False
        elif stype =='LIVE_CHANNEL':
            list_item.setProperty('IsPlayable', 'true')
            url = '{0}?action=Play&video={1}&ltype={2}'.format(_url, sid,'Live')
            is_folder = False
        else:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_season&title={1}&sid={2}&page=0'.format(_url,urllib_parse.quote_plus(title),sid)
            is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    #xbmcplugin.setContent(_handle, 'tvshows')
    xbmcplugin.endOfDirectory(_handle)

def list_season(seasonid):
    """
    Create the list of channels in the Kodi interface.
    """
    #web_pdb.set_trace()
    shows = cache.cacheFunction(get_season,seasonid)
    listing = []
    for title,icon,sid,stype,labels,tcount in shows:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]'%title)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)

        if stype=='EPISODE':
            list_item.setProperty('IsPlayable', 'true')
            url = '{0}?action=Play&video={1}&ltype={2}'.format(_url, sid,'Stream')
            is_folder = False
            xbmcplugin.setContent(_handle, 'tvshows')
        else:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_episodes&title={1}&sid={2}&page=0&total={3}'.format(_url,urllib_parse.quote_plus(title),sid,tcount)
            is_folder = True
        listing.append((url, list_item, is_folder))
    """
    if seasonid == '1700000029':
        list_item = xbmcgui.ListItem(label='[COLOR yellow]Season New[/COLOR]')
        list_item.setArt(icon)
        list_item.setInfo('video', labels)
        list_item.setProperty('IsPlayable', 'false')
        url = '{0}?action=list_episodes&title={1}&sid={2}&page=0&total={3}'.format(_url,'Season New',1500000766,100)
        is_folder = True
        listing.append((url, list_item, is_folder))
    """
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    #
    xbmcplugin.endOfDirectory(_handle)

    
def list_episodes(sid,title,page,total):
    """
    Create the list of episodes in the Kodi interface.
    """
    episodes = cache.cacheFunction(get_episodes,sid,title,page,total)
    listing = []
    
    for etitle,icon,eid,extid,labels,tcount in episodes:
        list_item = xbmcgui.ListItem(label=etitle)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)
        if 'Next Page' in etitle:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_episodes&sid={1}&title={2}&page={3}&total={4}'.format(_url, sid, title, eid,tcount)
            is_folder = True
        elif 'Go Page' in etitle:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=gopage&sid={1}&total={2}'.format(_url, sid,tcount)
            is_folder = True
        else:
            list_item.setProperty('IsPlayable', 'true')
            url = '{0}?action=Play&video={1}&ltype={2}'.format(_url, eid,'Stream')

            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'episodes')
    xbmcplugin.endOfDirectory(_handle)



def save_local(urlfile):
    content = requests.get(urlfile,headers=headers).content
    path=xbmc.translatePath("special://profile/temp/").decode('utf-8')
    if not xbmcvfs.exists(path):
            xbmcvfs.mkdir(path)
    filename=os.path.join(path, 'Temp.mpd')
    if os.path.exists(filename):
        xbmcvfs.delete(filename)
    f = xbmcvfs.File(filename,'w')
    result = f.write(content)
    f.close()
    return filename


class HttpHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def log_request(self, *args, **kwargs):
        pass

    def do_HEAD(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()

    def do_GET(self):

        self.path=self.server.file_name

        try:
            #url_array = urllib_parse.urlparse(self.server.stream_uri)
            base_url="/".join(self.server.stream_uri.split('?')[0].split('/')[:-1])         #'https://%s' % url_array.netloc
            content = requests.get(self.server.stream_uri,headers=headers).content
            self.send_response(200)

            ##self.send_header('Content-type','text/html')
            self.end_headers()  
            #send html message,
            replacement = six.StringIO(content)
            for line in replacement:
                self.wfile.write(line) if 'SegmentTemplate timescale="48000"' not in line else self.wfile.write('\t\t<SegmentTemplate timescale="48000" media="" initialization="" startNumber="1"/>\n')
                #%line[:line.find('media')])                 
                #xbmc.log('AJAY: %s' % line)
                if '<MPD' in line:
                    self.wfile.write('<BaseURL>%s/</BaseURL>\n' % base_url)

        except Exception as e:
            self.send_response(404, 'not found')
            self.end_headers()


def get_random_open_port():
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(("", 0))
        s.listen(1)
        port = s.getsockname()[1]
        s.close()
        return int(port)

def start_httpd(uri, file_name):
    port = get_random_open_port()
    httpd = socketserver.TCPServer(('127.0.0.1', port), HttpHandler)
  
    httpd.stream_uri = uri
    file_name='http://127.0.0.1:%d/%s' % (port, urllib_parse.quote(file_name))
    httpd.file_name = file_name
    httpd_thread = threading.Thread(target=httpd.serve_forever)
    httpd_thread.start()
    xbmc.log('HTTPD: started at %s/' % file_name)
    return file_name

def play_video(vid,ltype):
    """
    Play a video by the provided video id.

    :param vid: str
    """

    phdr = headers
    phdr.update({'x-playback-session-id': '00073cb0a77244c58c326835cfab222a-1618746054735'})
    phdr.update({'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36'})
    #web_pdb.set_trace()
    if ltype=='Live':
        url = 'https://apiv2.sonyliv.com/AGL/1.5/R/ENG/WEB/IN/CONTENT/VIDEOURL/VOD/%s/freepreview'%vid
    else:
        url = 'https://apiv2.sonyliv.com/AGL/1.5/R/ENG/WEB/IN/CONTENT/VIDEOURL/VOD/%s'%vid
    #url = 'https://apiv2.sonyliv.com/AGL/1.5/A/ENG/WEB/IN/DETAIL/%s'%vid
    r = requests.get(url, headers=phdr)
    if r.status_code > 400:
        return
    jd = r.json()
    stream_url = jd['resultObj'].get('videoURL').lstrip()
    #stream_url = jd['resultObj']['containers'][0]['platformVariants'][0].get('videoUrl').lstrip()
    title='Temp.mpd'
    if ltype!='Live':
        stream_url = start_httpd(stream_url, title)
    ##local_url=save_local(stream_url)
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setPath(stream_url)

    play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
    if (stream_url.find('mpd') != -1):
        play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        play_item.setMimeType('application/dash+xml')
    else:
        play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        play_item.setMimeType('application/vnd.apple.mpegurl')


    play_item.setContentLookup(False)
    play_item.setProperty('inputstream.adaptive.stream_headers', urllib_parse.urlencode(phdr))     

    #play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
    #lic_url=get_laurl(phdr,vid)
    #play_item.setProperty('inputstream.adaptive.license_key', lic_url)
    #xbmcaddon.Addon(id='inputstream.adaptive').setSetting(id='STREAMSELECTION', value="2")

    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring:
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(urllib_parse.parse_qsl(paramstring))
    # Check the parameters passed to the plugin

    if params:
        if params['action'] == 'list_item':
            if params['item'] == 'Channels':
                list_channels()
            elif params['item'] == 'Movies':
                list_moviegenres()
            elif params['item'] == 'Clear Cache':
                clear_cache()
        elif params['action'] == 'list_shows':
            list_shows(params['cid'])
        elif params['action'] == 'list_season':
            list_season(params['sid'])   
        elif params['action'] == 'list_movies':
            list_movies(params['mgid'],params['page'],params['url'],params['total'])
        elif params['action'] == 'list_episodes':
            list_episodes(params['sid'],params['title'],params['page'],params['total'])
        elif params['action'] == 'Play':
            play_video(params['video'],params['ltype'])
        elif params['action'] == 'gopage':
            go_page(params['sid'],params['total'])
    else:
        list_top()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
