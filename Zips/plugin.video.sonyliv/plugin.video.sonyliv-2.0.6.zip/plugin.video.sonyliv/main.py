

import sys

from kodi_six import xbmc, xbmcaddon, xbmcplugin, xbmcgui, xbmcvfs
from six.moves import urllib_parse, urllib_request 
import six
import re 
import requests
import time
import web_pdb
import socket
import threading
import os
from datetime import datetime
from json import dumps
import uuid
try:
    import StorageServer
except:
    import storageserverdummy as StorageServer

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

_addon = xbmcaddon.Addon()
_addonname = _addon.getAddonInfo('name')
_version = _addon.getAddonInfo('version')
_addonID = _addon.getAddonInfo('id')
_icon = _addon.getAddonInfo('icon')
_fanart = _addon.getAddonInfo('fanart')
_settings = _addon.getSetting

window = xbmcgui.Window(10000) # Home
#window.setProperty("LoadPage", 'True')

cache = StorageServer.StorageServer('sonyliv', _settings('timeout'))

#    

headers= {"Content-Type": "application/json",
    "x-via-device": "true",
    "app_version": "3.3.58"
    }


def get_token():
    url='https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/ALL/GETTOKEN'
    data = requests.get(url, headers=headers).json()
    return data['resultObj']

if 'security_token' not in headers:
    headers["security_token"] = get_token()

def clear_cache():
    """
    Clear the cache database.
    """
    msg = 'Cached Data has been cleared'
    cache.table_name = 'sonyliv'
    cache.cacheDelete('%get%')
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(_addonname, msg, 3000, _icon))


def get_laurl(thdr,tid):
    """
    Get the policy key.
    :return: string
    """
    laurl=[]
    la_hdr=thdr
    #la_hdr.update({'Content-Type': 'application/json'})
    url = 'https://apiv2.sonyliv.com/AGL/1.4/R/ENG/WEB/IN/CONTENT/GETLAURL'

    body = {"actionType":"play","assetId":tid,"browser": "Chrome","deviceId": la_hdr.get('x-playback-session-id'),"os": "Chrome","platform": "web"}

    body = dumps(body)

    data = requests.post(url,headers=la_hdr,data=body).json()

    laurl.append((data['resultObj'].get('laURL'),data['resultObj'].get('signature')))
    return laurl

def go_page(sid,total):
    load_page = window.getProperty("LoadPage")

    if load_page=='True':
        page=xbmcgui.Dialog().numeric(0,'Episodes Page')
        if page:
            page=int(page)
            pages=int(total)/10
            pages=pages+1 if int(total)%10 >0 else pages
            page=pages-1 if page>pages else page-1
            list_episodes(sid,'page',page,total)
            window.setProperty("CurPage", str(page))
    else:
        page = int(window.getProperty("CurPage"))
        window.setProperty("LoadPage", 'True')
        list_episodes(sid,'page',page,total)
    return 


def get_srt(vttfile):
    content = requests.get(vttfile,headers=headers).content
    replacement = re.sub(r'([\d]+)\.([\d]+)', r'\1,\2', content)
    replacement = re.sub(r'WEBVTT\n\n', '', replacement)
    replacement = re.sub(r'^\d+\n', '', replacement)
    replacement = re.sub(r'\n\d+\n', '\n', replacement)
    replacement = six.StringIO(replacement)
    idx = 1
    content = ''
    for line in replacement:
        if '-->' in line:
            if len(line.split(' --> ')[0]) < 12:
                line = re.sub(r'([\d]+):([\d]+),([\d]+)', r'00:\1:\2,\3', line)
            content += '%s\n%s'%(idx,line) 
            idx += 1
        else:
            content += line
    f = xbmcvfs.File('special://temp/TemporarySubs.en.srt','w')
    result = f.write(content)
    f.close()
    return 'special://temp/TemporarySubs.en.srt'

def get_top():
    """
    Get the list of countries.
    :return: list 532
    """
    MAINLIST = [('TV Shows','7738',43), ('Movies','7745',30), ('Sports','7750',35), ('Live TV','7878',9), ('Search','1',1), ('Clear Cache','2',2)]
    return MAINLIST


def get_channels(topid,pages):
    """
    Get the list of channels.
    :return: list
    """
    channels = []

    url = 'https://apiv2.sonyliv.com/AGL/2.4/A/ENG/WEB/IN/MH/PAGE/{}?kids_safe=true&from=1&to={}'.format(topid, pages)
    jd = requests.get(url,headers=headers).json()
    cnav = jd['resultObj']['containers']

    for cn in cnav:
        title = cn['metadata'].get('label')
        if title :
            #web_pdb.set_trace() 
            cid = cn['metadata'].get('id')
            if cn.get('assets'):
                stype= cn['assets']['containers'][0]['metadata'].get('contentSubtype')  if cn['assets']['containers'] else ''
            else:
                stype=''
            uri=cn['actions'][0].get('uri')
            total= cn['assets'].get('total') if cn.get('assets') else 100
            channels.append((title,cid,stype,uri,total))
    return channels

def get_shows(cid):
    """
    Get the list of shows.
    :return: list
    """
    shows = []
    nextpg = True
    page = 0  

    #url='https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN/PAGE/%s?from=0&to=9'%(cid)
    url='https://apiv2.sonyliv.com/AGL/1.6/A/ENG/WEB/IN/PAGE/%s'%(cid)
    jd = requests.get(url,headers=headers).json()

    items = jd['resultObj']['containers'][0]['assets']['containers']
    for item in items:
        title = item['metadata'].get('title')

        labels = {'title': title,
                  'genre': item['metadata'].get('genres'),
                  'plot': item['metadata'].get('longDescription'),
                  'mediatype': 'tvshow'
                 }
        uri=item['actions'][0].get('uri')
        if item['metadata'].get('emfAttributes'):
            fanart = item['metadata']['emfAttributes'].get('masthead_background')
            if not fanart:
                fanart = item['metadata']['emfAttributes'].get('masthead_background_mobile')

            icon = item['metadata']['emfAttributes'].get('masthead_foreground')
            poster = item['metadata']['emfAttributes'].get('portrait_thumb')
            thumb = item['metadata']['emfAttributes'].get('masthead_logo')

            images = {'poster': poster,
                   'icon': icon,
                   'thumb': thumb,
                   'fanart': fanart}
        else:
            images = {'poster': _icon,
                   'icon': _icon,
                   'thumb': _icon,
                   'fanart': _fanart}

        try:
            labels['aired'] = datetime.fromtimestamp(item['metadata'].get('contractStartDate')/1000.0).strftime('%Y-%m-%d')
        except:
            pass

        sid=item['id']
        stype=item['metadata'].get('objectSubtype')
        shows.append((title,images,sid,labels,stype,uri))
    return shows

def get_season(sid):
    """
    Get the list of episodes.
    :return: list
    """
    season = []

    url='https://apiv2.sonyliv.com/AGL/1.5/A/ENG/WEB/IN/DETAIL/'+sid
    jd = requests.get(url,headers=headers).json()
    
    
    items = jd['resultObj']['containers'][0]['containers']
    
    for item in items:
        subtype=item['metadata'].get('contentSubtype')
        if item.get('episodeCount'):
            tcount=item.get('episodeCount')
        else:
            tcount=100
        if subtype=='EPISODE':
            stitle = '%s Episode %s'%(item['metadata'].get('title'),item['metadata'].get('episodeNumber'))
            labels = {'title': stitle,
                      'duration': item['metadata'].get('duration'),
                      'episode': item['metadata'].get('episodeNumber'),
                      'year': item['metadata'].get('year'),
                      'tvshowtitle': stitle,
                      'mediatype': 'episode'
                     }
        else:
            stitle = item['metadata'].get('title')
            labels = {'title': stitle,
                      'mediatype': 'season'
                     }

        fanart = item['metadata']['emfAttributes'].get('tv_background_image')
        poster = item['metadata']['emfAttributes'].get('poster')
        icon = item['metadata']['emfAttributes'].get('landscape_thumb')
        thumb = item['metadata']['emfAttributes'].get('thumbnail')

        icon = {'poster': poster,
               'icon': icon,
               'thumb': thumb,
               'fanart': fanart}


        sid=item['id']
        labels['genre'] = item['metadata'].get('genres')
        labels['plot'] = item['metadata'].get('longDescription')
        labels['aired'] = datetime.fromtimestamp(item['metadata'].get('originalAirDate')/1000.0).strftime('%Y-%m-%d') if item['metadata'].get('originalAirDate') else None
        season.append((stitle,icon,sid,subtype,labels,tcount))

    return season

def get_episodes(sid,title,page,total):
    """
    Get the list of episodes.
    :return: list
    """
    episodes = []
    page = int(page)
    fpage=int(page)*10
    tpage=(int(page)+1)*10-1

    url='https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN/CONTENT/DETAIL/BUNDLE/%s?from=%s&to=%s'%(sid,fpage,tpage)
    jd = requests.get(url,headers=headers).json()
    items = jd['resultObj']['containers'][0]['containers']
    for item in items:
        etitle = '{} - Episodes {}'.format(six.ensure_str(item['metadata'].get('episodeTitle'), encoding='utf-8', errors='strict'),item['metadata'].get('episodeNumber'))
        eid=item.get('id')
        extid=item['metadata'].get('externalId')
        plot=item['metadata'].get('longDescription')
        if item['metadata']['emfAttributes'].get('cast_and_crew') is not None:
            plot=plot+'\n\n'+item['metadata']['emfAttributes'].get('cast_and_crew')

        labels = {'title': etitle,
                  'genre': item['metadata'].get('genres'),
                  #'cast':item['metadata'].get('actors'),
                  'plot': plot,
                  'duration': item['metadata'].get('duration'),
                  'episode': item['metadata'].get('episodeNumber'),
                  'tvshowtitle': etitle,
                  'year':item['metadata'].get('year'),
                  'aired':datetime.fromtimestamp(item['metadata'].get('originalAirDate')/1000.0).strftime('%Y-%m-%d') if item['metadata'].get('originalAirDate') else None,
                  'mediatype': 'episode'
                 }
        fanart = item['metadata']['emfAttributes'].get('tv_background_image')
        poster = item['metadata']['emfAttributes'].get('poster')
        icon = item['metadata']['emfAttributes'].get('landscape_thumb')
        thumb = item['metadata']['emfAttributes'].get('thumbnail')

        images = {'poster': poster,
               'icon': icon,
               'thumb': thumb,
               'fanart': fanart}

        episodes.append((etitle,images,eid,extid,labels,total))
    total=items[0].get('episodeCount') if items[0].get('episodeCount') is not None else total
    page += 1
    BalCount=int(total)-page*10
    if BalCount > 0:
        pages=int(total)/10
        pages=pages+1 if int(total)%10 >0 else pages
        etitle = 'Next Page... (Page %s of %s)'%(page,pages)
        labels = {}
        images = {'poster': _icon,
               'icon': _icon,
               'thumb': _icon,
               'fanart': _fanart}
        episodes.append((etitle,images,page,extid,labels,total))
        etitle = 'Go Page...'
        labels = {}
        icon = {'poster': _icon,
               'icon': _icon,
               'thumb': _icon,
               'fanart': _fanart}
        episodes.append((etitle,images,page,extid,labels,total))
    return episodes

def get_video(gid,page,uri,total):
    """
    Get the list of video.
    :return: list
    """
    video = []
    page = int(page)
    fpage=int(page)*10
    tpage=(int(page)+1)*10-1

    if (uri.find('SEARCH') == -1):
        url='https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN/PAGE/%s?from=0&to=9'%(gid)
        NoNext=True
        jd = requests.get(url,headers=headers).json()
        items = jd['resultObj']['containers'][0]['assets']['containers']
    else:
        url='https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN%s&from=%s&to=%s'%(uri,fpage,tpage)
        NoNext=False
        jd = requests.get(url,headers=headers).json()
        items = jd['resultObj']['containers']
    
    for item in items:
        mtitle = six.ensure_str(item['metadata'].get('title'), encoding='utf-8', errors='strict')
        if item['metadata'].get('episodeTitle'):
            if mtitle.strip()!=item['metadata'].get('episodeTitle').strip():
                mtitle = '{} ({})'.format(six.ensure_str(item['metadata'].get('episodeTitle'), encoding='utf-8', errors='strict'),mtitle)
        mid=item.get('id')

        mextid=item['metadata'].get('externalId')
        subtype=item['metadata'].get('contentSubtype')
        plot=item['metadata'].get('longDescription')

        if item['metadata'].get('emfAttributes'):
            if item['metadata']['emfAttributes'].get('cast_and_crew'):
                plot=plot+'\n\n'+item['metadata']['emfAttributes'].get('cast_and_crew')
            if item['metadata']['emfAttributes'].get('is_preview_enabled')==False:
                subtype='EPISODE'
            fanart = item['metadata']['emfAttributes'].get('tv_background_image')
            poster = item['metadata']['emfAttributes'].get('portrait_thumb')
            if not poster:
                poster = item['metadata']['emfAttributes'].get('thumbnail')
            icon = item['metadata']['emfAttributes'].get('landscape_thumb')
            thumb = item['metadata']['emfAttributes'].get('thumbnail')

            images = {'poster': poster,
                   'icon': icon,
                   'thumb': thumb,
                   'fanart': fanart}
        else:
            images = {'poster': _icon,
                   'icon': _icon,
                   'thumb': _icon,
                   'fanart': _fanart}

        labels = {'title': mtitle,
                  'genre': item['metadata'].get('genres'),
                  #'cast':item['metadata']['emfAttributes'].get('cast_and_crew'),
                  'plot': plot,
                  'duration': item['metadata'].get('duration'),
                  'year':item['metadata'].get('year'),
                  'mediatype': 'movie'
                 } 

        try:
            labels['premiered'] = datetime.fromtimestamp(item['metadata'].get('originalAirDate')/1000.0).strftime('%Y-%m-%d')
        except:
            pass

        video.append((mtitle,images,mid,mextid,subtype,labels,total))
    if NoNext==False:
        page += 1
        BalCount=int(total)-page*10
        if BalCount > 0:
            pages=(int(total)/10)
            pages=pages+1 if int(total)%10 >0 else pages
            mtitle = 'Next Page... (Page %s of %s)'%(page,pages)
            labels = {}
            icon = {'poster': _icon,
                   'icon': _icon,
                   'thumb': _icon,
                   'fanart': fanart}
            video.append((mtitle,images,page,mextid,subtype,labels,total))

    return video

def get_search(sid):
    """
    Get the list of shows.
    :return: list
    """
    search = []
    nextpg = True
    page = 0  

    url='https://apiv2.sonyliv.com/AGL/2.4/A/ENG/WEB/IN/MH/TRAY/SEARCH?query=%s&from=0&to=9&kids_safe=true'%(sid)

    jd = requests.get(url,headers=headers).json()
    for x in range(2):
        items = jd['resultObj']['containers'][x]['containers']
        for item in items:
            title = six.ensure_str(item['metadata'].get('title'), encoding='utf-8', errors='strict')
            if item['metadata'].get('episodeTitle'):
                if title.strip()!=item['metadata'].get('episodeTitle').strip():
                    title = '{} ({})'.format(six.ensure_str(item['metadata'].get('episodeTitle'), encoding='utf-8', errors='strict'),title)

            labels = {'title': title,
                      'genre': item['metadata'].get('genres'),
                      'plot': item['metadata'].get('longDescription'),
                      'mediatype': 'tvshow'
                     }

            if item['metadata'].get('emfAttributes'):
                fanart = item['metadata']['emfAttributes'].get('masthead_background')
                if not fanart:
                    fanart = item['metadata']['emfAttributes'].get('masthead_background_mobile')

                icon = item['metadata']['emfAttributes'].get('masthead_foreground')
                poster = item['metadata']['emfAttributes'].get('portrait_thumb')
                thumb = item['metadata']['emfAttributes'].get('masthead_logo')

                images = {'poster': poster,
                       'icon': icon,
                       'thumb': thumb,
                       'fanart': fanart}
            else:
                images = {'poster': _icon,
                       'icon': _icon,
                       'thumb': _icon,
                       'fanart': _fanart}

            try:
                labels['aired'] = datetime.fromtimestamp(item['metadata'].get('contractStartDate')/1000.0).strftime('%Y-%m-%d')
            except:
                pass

            sid=item['id']
            stype=item['metadata'].get('objectSubtype')
            uri=item['actions'][0].get('uri')
            total= item['assets'].get('total') if item.get('assets') else 100
            search.append((title,images,sid,stype,x,total))
    return search


def list_top():
    """
    Create the list of countries in the Kodi interface.
    """
    items = get_top()
    listing = []
    for title,topid,pages in items:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setInfo('video', {'title': title})
        list_item.setProperty('IsPlayable', 'false')
        list_item.setArt({'poster': _icon,
                          'icon': _icon,
                          'thumb': _icon,
                          'fanart': _fanart})
        url = '{0}?action=list_second&topid={1}&pages={2}'.format(_url, topid,pages)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    #xbmcplugin.setContent(_handle, 'addons')
    xbmcplugin.endOfDirectory(_handle)

def list_channels(topid,pages):
    """
    Create the list of countries in the Kodi interface.
    """
    channels = cache.cacheFunction(get_channels,topid,pages)
    listing = []
    #

    for title,cid,stype,uri,tcount in channels:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]'%title)
        list_item.setProperty('IsPlayable', 'false')
        list_item.setArt({'poster': _icon,
                          'icon': _icon,
                          'thumb': _icon,
                          'fanart': _fanart})
        list_item.setInfo('video', {'title': title})

        if stype in ['CLIP','BEHIND_THE_SCENES','MOVIE','LIVE_CHANNEL','LIVE_SPORT', 'SPORTS_CLIPS','HIGHLIGHTS']:
            url = '{0}?action=list_video&mgid={1}&url={2}&page=0&total={3}'.format(_url, cid,urllib_parse.quote_plus(uri),tcount)
        else:
            url = '{0}?action=list_shows&cid={1}'.format(_url, cid)

        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

def list_shows(cid):
    """
    Create the list of channels in the Kodi interface.
    """

    shows = cache.cacheFunction(get_shows,cid)
    listing = []
    
    for title,icon,sid,labels,stype,uri in shows:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]'%title)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)
        list_item.setProperty('IsPlayable', 'false')

        if stype in ['LAUNCHER']:
            url = '{0}?action=list_video&mgid={1}&url={2}&page=0&total={3}'.format(_url, sid,urllib_parse.quote_plus(uri),10)
        else:
            url = '{0}?action=list_season&title={1}&sid={2}&page=0'.format(_url,six.ensure_str(title, encoding='utf-8', errors='strict'),sid)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    #xbmcplugin.setContent(_handle, 'tvshows')
    xbmcplugin.endOfDirectory(_handle)

def list_season(seasonid):
    """
    Create the list of channels in the Kodi interface.
    """
    shows = cache.cacheFunction(get_season,seasonid)
    listing = []
    for title,icon,sid,stype,labels,tcount in shows:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]'%title)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)

        if stype=='EPISODE':
            list_item.setProperty('IsPlayable', 'true')
            url = '{0}?action=Play&video={1}&ltype={2}'.format(_url, sid,'Stream')
            is_folder = False
            xbmcplugin.setContent(_handle, 'tvshows')
        else:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_episodes&sid={1}&title={2}&page=0&total={3}'.format(_url,sid,urllib_parse.quote_plus(title),tcount)
            is_folder = True
        listing.append((url, list_item, is_folder))

    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

  
def list_episodes(sid,title,page,total):
    """
    Create the list of episodes in the Kodi interface.

    """
    window.setProperty("LoadPage", 'True')
    episodes = cache.cacheFunction(get_episodes,sid,title,page,total)
    listing = []
    
    for etitle,icon,eid,extid,labels,tcount in episodes:
        list_item = xbmcgui.ListItem(label=etitle)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)
        if 'Next Page' in etitle:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_episodes&sid={1}&title={2}&page={3}&total={4}'.format(_url, sid, 'Next', eid,tcount)
            is_folder = True
        elif 'Go Page' in etitle:
            list_item.setProperty('IsPlayable', 'false')
            #url = '{0}?action=list_episodes&sid={1}&title={2}&page={3}&total={4}'.format(_url, sid, 'GoPage', eid,tcount)
            url = '{0}?action=gopage&sid={1}&total={2}'.format(_url, sid,tcount)
            is_folder = True
        else:
            list_item.setProperty('IsPlayable', 'true')
            url = '{0}?action=Play&video={1}&ltype={2}'.format(_url, eid,'Stream')
            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'episodes')
    xbmcplugin.endOfDirectory(_handle)

def list_video(gid,uri,page,total):
    """
    Create the list of episodes in the Kodi interface.
    """

    video = cache.cacheFunction(get_video,gid,page,uri,total)
    listing = []

    for title,icon,mid,extid,stype,labels,tcount in video:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)

        if 'Next Page' in title:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_video&mgid={1}&url={2}&page={3}&total={4}'.format(_url,gid,urllib_parse.quote_plus(uri),mid,tcount)
            is_folder = True
        else:
            list_item.setProperty('IsPlayable', 'true')
            list_item.addStreamInfo('video', {'codec': 'h264'})
            #list_item.addStreamInfo('audio', { 'codec': 'mp4', 'channels': 2 })
            if stype in ('LIVE_CHANNEL','LIVE_SPORT'):
                url = '{0}?action=Play&video={1}&ltype={2}'.format(_url, mid,'Live')
            else:
                url = '{0}?action=Play&video={1}&ltype={2}'.format(_url, mid,'Stream')

            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)


def get_user_input():
    kb = xbmc.Keyboard('', 'Search for Movies/TV Shows/Trailers/Videos in all languages')
    kb.doModal()  # Onscreen keyboard appears
    if not kb.isConfirmed():
        return

    # User input
    return kb.getText()

def list_search(sid):
    """
    Create the list of channels in the Kodi interface.
    """

    query = get_user_input()
    if not query:
        return []
    
    #shows = cache.cacheFunction(get_search,query)
    shows = get_search(query)
    listing = []

    for title,images,sid,stype,xidx,tcount in shows:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]'%title)
        list_item.setArt(images)
        #list_item.setInfo('video', labels)
        list_item.setProperty('IsPlayable', 'false')
        if xidx==0:
            url = '{0}?action=list_season&title={1}&sid={2}&page=0'.format(_url,urllib_parse.quote_plus(title),sid)
            is_folder = True 
        else:
            url = '{0}?action=Play&video={1}&ltype={2}'.format(_url, sid,'Stream')
            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'tvshows')
    xbmcplugin.endOfDirectory(_handle)


def play_video(vid,ltype):
    """
    Play a video by the provided video id.

    :param vid: str
    """

    phdr = headers    

    phdr.update({'x-playback-session-id': '%s-%d' % (uuid.uuid4().hex, time.time() * 1000)})
    phdr.update({'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36'})
    phdr.update({'accept': '*/*'})
    phdr.update({'accept-encoding': 'gzip, deflate, br'})
    phdr.update({'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,hi;q=0.7'})
    phdr.update({'cache-control': 'no-cache'})
    phdr.update({'origin': 'https://www.sonyliv.com'})
    phdr.update({'content-type': 'application/octet-stream'})
    if ltype=='Live':
        url = 'https://apiv2.sonyliv.com/AGL/1.5/R/ENG/WEB/IN/CONTENT/VIDEOURL/VOD/%s/freepreview'%vid
    else:
        url = 'https://apiv2.sonyliv.com/AGL/1.5/R/ENG/WEB/IN/CONTENT/VIDEOURL/VOD/%s'%vid

    r = requests.get(url, headers=phdr)
    jd = r.json()
    if r.status_code > 400:
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(_addonname, jd.get('message'), 3500, _icon))
        return
    #jd = r.json()
    stream_url = jd['resultObj'].get('videoURL').lstrip()

    #stream_url=stream_url.replace('.mpd', '.m3u8').replace('/DASH/', '/HLS/')

    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setPath(stream_url)

    #Kodi_version=int(xbmc.getInfoLabel("System.BuildVersion").split('.')[0])
    #Kodi_version>=19
    if six.PY3:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
    else:
        play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')

    if (stream_url.find('mpd') != -1):
        play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        play_item.setMimeType('application/dash+xml')
    else:
        play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        play_item.setMimeType('application/vnd.apple.mpegurl')
    
    play_item.setContentLookup(False)

    if jd['resultObj'].get('isEncrypted'):

        GETLAURL=get_laurl(phdr,vid)
        lic_url='%s&kid=%s' %(GETLAURL[0][0],jd['resultObj'].get('drm_video_kid'))
        signature=GETLAURL[0][1]
        #phdr.update({'content-type':'application/octet-stream'})
        #phdr.update({'drm_video_kid': jd['resultObj'].get('drm_video_kid')})
        phdr.update({'authority': 'wv.service.expressplay.com'})
        #phdr.update({'utoken-drm': signature})
        license_key = '%s|%s|R{SSM}|' % (lic_url,urllib_parse.urlencode(phdr))
        #play_item.setProperty('inputstream.adaptive.server_certificate',signature)
    else:
        license_key = '|%s|R{SSM}|' % (urllib_parse.urlencode(phdr))


    play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
    play_item.setProperty('inputstream.adaptive.license_key', license_key)
    play_item.setProperty('inputstream.adaptive.stream_headers', urllib_parse.urlencode(phdr))

    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring:
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(urllib_parse.parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    
    if params:
        if params['action'] == 'list_second':
            if params['topid'] == '1':
                list_search(params['topid'])
            elif params['topid'] == '2':
                clear_cache()
            else:
                list_channels(params['topid'],params['pages'])
        elif params['action'] == 'list_shows':
            list_shows(params['cid'])
        elif params['action'] == 'list_season':
            list_season(params['sid'])   
        elif params['action'] == 'list_video':
            list_video(params['mgid'],params['url'],params['page'],params['total'])
        elif params['action'] == 'list_episodes':
            list_episodes(params['sid'],params['title'],params['page'],params['total'])
        elif params['action'] == 'Play':
            window.setProperty("LoadPage", 'False')
            play_video(params['video'],params['ltype'])
        elif params['action'] == 'gopage':
            go_page(params['sid'],params['total'])

    else:
        list_top()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring

    router(sys.argv[2][1:])
